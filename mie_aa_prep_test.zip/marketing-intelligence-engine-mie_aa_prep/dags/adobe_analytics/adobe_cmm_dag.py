"""
DAG to run Adobe Analytics CMM preparation and aggregation Glue jobs.
This DAG handles the ETL pipeline for Adobe Campaign Metrics data:
1. First extracts and transforms raw data (ie_adobe_cmm_prep)
2. Then performs aggregation and loads to Redshift (ie_adobe_cmm_agg)
"""

from datetime import datetime, timedelta
import boto3
import json
from airflow.decorators import dag, task
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.sensors.glue import GlueJobSensor


@dag(
    dag_id='adobe_cmm_pipeline',
    description='Process Adobe Analytics CMM data from raw to refined and load to Redshift',
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['adobe', 'cmm'],
    default_args={
        'owner': 'data-engineering',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5)
    }
)
def adobe_cmm_pipeline():
    
    @task
    def get_job_arguments(**kwargs):
        """
        Determine job arguments based on execution date or manual trigger parameters.
        For batch processing, returns start_date and end_date.
        For daily processing, returns an empty dict.
        """
        # Check if start_date and end_date were provided as configuration
        dag_run = kwargs.get('dag_run')
        if dag_run and dag_run.conf and 'start_date' in dag_run.conf and 'end_date' in dag_run.conf:
            return {
                '--start_date': dag_run.conf['start_date'],
                '--end_date': dag_run.conf['end_date'],
                '--job-bookmark-option': 'job-bookmark-disable'  # Disable bookmarks for batch runs
            }

        # Default to daily processing (previous day)
        # Disable job bookmark, since job auto manages bookmark
        return {
            '--job-bookmark-option': 'job-bookmark-disable'
        }

    # Task to run the CMM Prep Glue job
    prep_job = GlueJobOperator(
        task_id='run_cmm_prep_job',
        job_name='ie_adobe_cmm_prep',
        script_location='s3://873109961464-glue-scripts/scripts/mie/ie_adobe_cmm_prep.py',
        script_args=get_job_arguments(),
        region_name='us-west-2',
        iam_role_name='delegate-admin-glue-service',
        create_job_kwargs={
            'GlueVersion': '5.0',
            'NumberOfWorkers': 2,
            'WorkerType': 'G.1X',
            'Timeout': 60,  # 60 minutes
            'MaxRetries': 0
        }
    )

    # Sensor to wait for the CMM Prep job to complete
    wait_for_prep_job = GlueJobSensor(
        task_id='wait_for_cmm_prep_job',
        job_name='ie_adobe_cmm_prep',
        run_id="{{ task_instance.xcom_pull(task_ids='run_cmm_prep_job') }}",
        region_name='us-west-2',
        poke_interval=60,  # Check every 60 seconds
        timeout=3600      # Time out after 1 hour
    )

    # Task to run the CMM Aggregation Glue job
    agg_job = GlueJobOperator(
        task_id='run_cmm_agg_job',
        job_name='ie_adobe_cmm_agg',
        script_location='s3://873109961464-glue-scripts/scripts/mie/ie_adobe_cmm_agg.py',
        region_name='us-west-2',
        iam_role_name='AWSGlueServiceRole-DataLake',
        create_job_kwargs={
            'GlueVersion': '5.0',
            'NumberOfWorkers': 2,
            'WorkerType': 'G.1X',
            'Timeout': 60,  # 60 minutes
            'MaxRetries': 0
        }
    )

    # Sensor to wait for the CMM Aggregation job to complete
    wait_for_agg_job = GlueJobSensor(
        task_id='wait_for_cmm_agg_job',
        job_name='ie_adobe_cmm_agg',
        run_id="{{ task_instance.xcom_pull(task_ids='run_cmm_agg_job') }}",
        region_name='us-west-2',
        poke_interval=60,  # Check every 60 seconds
        timeout=3600      # Time out after 1 hour
    )

    # Define the workflow
    get_job_arguments() >> prep_job >> wait_for_prep_job >> agg_job >> wait_for_agg_job

# Instantiate the DAG
adobe_cmm_pipeline()

