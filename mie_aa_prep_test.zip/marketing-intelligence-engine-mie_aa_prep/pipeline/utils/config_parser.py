import json
import sys
import os
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta

from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession

from dynamodb_handler import DynamodbHandler
from constants import DAY_FORMAT, DATE_TIME_FORMAT, JobStatus
from entities.job_run import JobRun

# Set up logging
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger(__name__)


class ConfigParser:
    """
    Singleton class for parsing job configurations and initializing Spark context.
    Handles job parameter parsing, date calculations, and Spark/Glue context initialization.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(ConfigParser, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, job_id: str = None, config_path: str = None):
        """
        Initialize ConfigParser with a job_id to fetch from DynamoDB

        Args:
            job_id: Optional job ID to use instead of reading from args
            config_path: Optional path to configuration file
        """
        # Skip initialization if already done
        if self._initialized:
            return

        logger.info("Initializing ConfigParser")
        self._initialized = True
        self.current_date = datetime.now()

        self.job_config = None
        self.spark_context = None
        self.glue_context = None
        self.spark = None
        self.job = None

        self.start_date = None
        self.end_date = None

        # Process arguments
        self.args = self.process_args()
        self.job_id = job_id or self.args.get('job_id')

        if not self.job_id:
            raise ValueError("No job_id provided in arguments or constructor")

        # Load config and job run data
        self.dynamodb_handler = DynamodbHandler()
        self.job_config = self.dynamodb_handler.get_job_config(self.job_id)
        self.job_run = self.dynamodb_handler.get_job_run(self.job_id)

        # Set date ranges
        self.set_date()
        logger.info(f"Job ID: {self.job_id}, Start Date: {self.start_date}, End Date: {self.end_date}")
        self.run_id = self.args.get('JOB_RUN_ID', None)
        self.current_job_run = self.create_job_run()
        self.dynamodb_handler.store_job_run(self.current_job_run)

    @staticmethod
    def process_args() -> Dict[str, str]:
        """
        Process command line arguments for Glue jobs.

        Returns:
            Dictionary of argument names and values
        """
        parameters = ['JOB_NAME']
        optional_parameters = ['start_date', 'end_date', 'job_id']

        for op in optional_parameters:
            if f'--{op}' in sys.argv:
                parameters.append(op)

        return getResolvedOptions(sys.argv, parameters)

    def create_job_run(self) -> JobRun:
        """
        Create a JobRun object based on the current job configuration and run history.
        :return:
        """
        job_run = JobRun()
        job_run.set_job_run({
            'job_id': self.job_id,
            'last_process_date': self.current_date.strftime(DATE_TIME_FORMAT),
            'start_date': self.start_date.strftime(DAY_FORMAT) if self.start_date else None,
            'end_date': self.end_date.strftime(DAY_FORMAT) if self.end_date else None,
            'run_id': self.run_id,
            'historical_refill': False,  # Set to False by default, can be modified later
            'status': JobStatus.RUNNING  # Default status
        })
        return job_run

    def store_status(self, status: JobStatus) -> None:
        """
        Store the current job run status in DynamoDB.

        Args:
            status: Status of the job run (e.g., 'SUCCESS', 'FAILURE')
        """
        if not self.current_job_run:
            raise ValueError("Job run not initialized")

        self.current_job_run.set_status(status)
        self.dynamodb_handler.store_job_run(self.current_job_run)
        logger.info(f"Stored job run status: {status.value} for job_id: {self.job_id}")

    def init_spark(self) -> Dict[str, Any]:
        """
        Initializes Spark and Glue contexts, and starts a Glue job.

        Returns:
            Dictionary containing Spark and Glue context objects

        Raises:
            Exception: If Spark initialization fails
        """
        try:
            logger.info("Initializing Spark and Glue contexts")
            # Initialize Spark and Glue contexts
            self.spark_context = SparkContext()
            self.glue_context = GlueContext(self.spark_context)
            self.spark = self.glue_context.spark_session
            self.job = Job(self.glue_context)

            # Start the job
            self.job.init(self.args['JOB_NAME'], self.args)
            logger.info(f"Spark session initialized for job: {self.args['JOB_NAME']}")

            # Return context objects for convenience
            return {
                'spark_context': self.spark_context,
                'glue_context': self.glue_context,
                'spark': self.spark,
                'job': self.job,
            }
        except Exception as e:
            logger.error(f"Failed to initialize Spark: {str(e)}")
            raise

    def set_date_from_args(self) -> None:
        """
        Parse start_date and end_date from command line arguments if provided.
        Converts string dates to datetime objects.
        """
        if self.args.get('start_date'):
            try:
                self.start_date = datetime.strptime(self.args['start_date'], DAY_FORMAT)
                logger.info(f"Using start_date from arguments: {self.start_date}")
            except ValueError as e:
                logger.error(f"Invalid start_date format: {self.args['start_date']}, expected {DAY_FORMAT}")
                raise

        if self.args.get('end_date'):
            try:
                self.end_date = datetime.strptime(self.args['end_date'], DAY_FORMAT)
                logger.info(f"Using end_date from arguments: {self.end_date}")
            except ValueError as e:
                logger.error(f"Invalid end_date format: {self.args['end_date']}, expected {DAY_FORMAT}")
                raise

    def set_date_from_table(self) -> None:
        """
        Set start_date and end_date based on job configuration and job run history.

        If dates are not provided via arguments, this method determines them based on:
        1. Last executed run (if available)
        2. Offset values from job configuration
        """
        # Skip if both dates are already set
        if self.start_date is not None and self.end_date is not None:
            logger.info("Start date and end date already set, skipping last job run check.")
            return

        if self.job_run and self.job_run.end_date:
            # Previous run exists, use its end date as start date if not set
            if self.start_date is None:
                self.start_date = self.job_run.end_date
                logger.info(f"Setting start_date from last job run end_date: {self.start_date}")

            if self.end_date is None:
                self.end_date = datetime.now() - timedelta(days=self.job_config.end_date_offset)
                logger.info(f"Setting end_date to current time minus offset: {self.end_date}")
        else:
            # No previous run, use offsets from configuration
            if self.start_date is None:
                self.start_date = datetime.now() - timedelta(days=self.job_config.start_date_offset)
                logger.info(f"No previous run, setting start_date using offset: {self.start_date}")

            if self.end_date is None:
                self.end_date = datetime.now() - timedelta(days=self.job_config.end_date_offset)
                logger.info(f"No previous run, setting end_date using offset: {self.end_date}")

    def set_date_from_dependency(self) -> None:
        # Skip if both dates are already set
        if self.start_date is not None and self.end_date is not None:
            logger.info("Start date and end date already set, skipping dependency check.")
            return

        dependency_job_run = self.dynamodb_handler.get_job_run(self.job_config.dependency)
        logger.info(f"Checking dependency job run: {dependency_job_run.get_job_run_dict()}")
        if dependency_job_run and dependency_job_run.start_date and dependency_job_run.end_date:
            if self.start_date is None:
                self.start_date = dependency_job_run.start_date
                logger.info(f"Setting start_date from dependency job run: {self.start_date}")

            if self.end_date is None:
                self.end_date = dependency_job_run.end_date
                logger.info(f"Setting end_date from dependency job run: {self.end_date}")

    def set_date(self) -> None:
        """
        Set start_date and end_date by combining argument values and configuration values.
        Arguments take precedence over configuration values.
        """
        logger.info("Setting date range for job run")
        self.set_date_from_args()
        logger.info(f"{self.job_config.get_config_dict()} - Job Configuration")
        if self.job_config.dependency:
            # update using dependency job run history for start_date and end_date
            self.set_date_from_dependency()

        self.set_date_from_table()
        if self.start_date > self.end_date:
            logger.warning("Start date cannot be after end date. Swapping dates.")
            self.start_date, self.end_date = self.end_date, self.start_date
        logger.info(f"Final date range: Start Date: {self.start_date}, End Date: {self.end_date}")
