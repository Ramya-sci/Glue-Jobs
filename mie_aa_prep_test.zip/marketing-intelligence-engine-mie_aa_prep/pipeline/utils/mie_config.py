import boto3
from datetime import datetime, timedelta

def get_job_config(job_id, dynamo_client, config_table_name):
    """
    Retrieve the job configuration from DynamoDB using job_id.
    """
    response = dynamo_client.get_item(
        TableName=config_table_name,
        Key={'job_id': {'S': job_id}}
    )
    item = response.get('Item', {})
    config = {
        'schedule_type': item.get('schedule_type', {}).get('S', 'daily'),
        'start_date_offset': int(item.get('start_date_offset', {}).get('N', '0') or item.get('start_date_offset', {}).get('S', '0')),
        'end_date_offset': int(item.get('end_date_offset', {}).get('N', '0') or item.get('end_date_offset', {}).get('S', '0')),
    }
    return config

def get_dates(job_id, dynamo_client, config_table_name, job_args, current_utc):
    """
    Returns a dict with start_date, end_date, and a list of all dates to process.
    Handles both daily and batch modes.
    """
    config = get_job_config(job_id, dynamo_client, config_table_name)
    schedule_type = config['schedule_type'].lower()

    if schedule_type == "daily":
        offset = int(config.get('start_date_offset', 0))
        target_date = current_utc - timedelta(days=offset)
        start_date = end_date = target_date.strftime("%Y-%m-%d")
        date_list = [target_date]
    elif schedule_type == "batch":
        start_date = job_args['start_date']
        end_date = job_args['end_date']
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        date_list = []
        current_date = start_dt
        while current_date <= end_dt:
            date_list.append(current_date)
            current_date += timedelta(days=1)
    else:
        raise ValueError(f"Unknown schedule type: {schedule_type}")

    return {
        'start_date': start_date,
        'end_date': end_date,
        'date_list': date_list
    }

def update_job_run_history(job_id, dynamo_client, history_table_name, run_id, job_status, start_date, end_date, last_process_date):
    """
    Update job run history in DynamoDB using job_id.
    """
    dynamo_client.put_item(
        TableName=history_table_name,
        Item={
            'job_id': {'S': job_id},
            'run_id': {'S': run_id},
            'job_status': {'S': job_status},
            'start_date': {'S': start_date},
            'end_date': {'S': end_date},
            'last_process_date': {'S': last_process_date}
        }
    )