import logging
import zipfile
from io import BytesIO
from datetime import datetime, timedelta
from typing import List, Optional

import boto3
from botocore.exceptions import ClientError

from config_parser import ConfigParser
from storage.s3_storage_service import FilePath
from entities.job_config import JobS3Params

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FileHandler:
    """
    Handler for file operations, especially for handling compressed files in S3.
    """

    def __init__(self, region_name: str = "us-east-1"):
        """
        Initialize the file handler with AWS region.

        Args:
            region_name: AWS region name, defaults to us-east-1
        """
        try:
            self.s3_client = boto3.client('s3', region_name=region_name)
            self.config_parser = ConfigParser()
            self.source = self.config_parser.job_config.source
            self.extracted = self.config_parser.job_config.extracted
            logger.info("FileHandler initialized")
        except Exception as e:
            logger.error(f"Failed to initialize FileHandler: {str(e)}")
            raise

    @staticmethod
    def build_s3_path_prefix(s3params: JobS3Params, date: datetime) -> str:
        """
        Builds an S3 path from the given S3 parameters and date.

        Args:
            s3params: JobS3Params object containing S3 parameters
            date: Datetime object representing the date to format

        Returns:
            Full S3 path as a string

        Raises:
            ValueError: If required parameters are missing
        """
        if not s3params.bucket or not s3params.prefix:
            raise ValueError("Bucket and prefix must be specified in S3 parameters.")

        file_path = s3params.prefix

        # Add partition if specified
        if s3params.partition is not None and s3params.partition.get('format', None) is not None:
            partition = date.strftime(s3params.partition['format'])
            file_path = f"{file_path}/{partition}"

        # Add file pattern if specified
        if s3params.file_pattern is not None:
            if not isinstance(date, datetime):
                raise ValueError("Date must be a datetime object when file_pattern is specified.")
            file_pattern = date.strftime(s3params.file_pattern)
            file_path = f"{file_path}/{file_pattern}"

        return file_path

    def _unzip_and_upload_file(self, current_date: datetime) -> FilePath:
        """
        Unzips a file from S3 and uploads the extracted content back to S3.

        Args:
            current_date: datetime object representing the date for which to process the file

        Returns:
            FilePath object containing the bucket and key of the extracted file

        Raises:
            ValueError: If no files found in the ZIP
            ClientError: For S3 client errors
        """
        input_key = self.build_s3_path_prefix(self.source, current_date)
        output_key = self.build_s3_path_prefix(self.extracted, current_date)
        source_bucket_name = self.source.bucket
        extracted_bucket_name = self.extracted.bucket

        logger.info(f"Processing file for date {current_date}: s3://{source_bucket_name}/{input_key}")

        try:
            # Check if the source file exists
            self.s3_client.head_object(Bucket=source_bucket_name, Key=input_key)

            # Get the zip file
            response = self.s3_client.get_object(Bucket=source_bucket_name, Key=input_key)
            zip_content = response['Body'].read()

            # Extract the contents
            with zipfile.ZipFile(BytesIO(zip_content), 'r') as zip_ref:
                file_names = zip_ref.namelist()
                if not file_names:
                    logger.error(f"No files in ZIP: {input_key}")
                    raise ValueError(f"No files found in ZIP: {input_key}")

                # Extract the first file
                extracted_data = zip_ref.read(file_names[0])
                logger.info(f"Extracted file '{file_names[0]}' from ZIP")

            # Upload the extracted data back to S3
            self.s3_client.put_object(Bucket=extracted_bucket_name, Key=output_key, Body=extracted_data)
            logger.info(f"Unzipped file written to S3: s3://{extracted_bucket_name}/{output_key}")
            # Remove the file name from the output key to get the folder path
            output_key = output_key.rsplit('/', 1)[0]   # Ensure
            return FilePath(extracted_bucket_name, output_key)

        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                logger.error(f"Source file not found: s3://{source_bucket_name}/{input_key}")
                raise ValueError(f"Source file not found: s3://{source_bucket_name}/{input_key}")
            else:
                logger.error(f"S3 error processing file: {str(e)}")
                raise
        except Exception as e:
            logger.error(f"Failed to unzip/upload for {input_key}: {str(e)}")
            raise

    def unzip_and_upload(self) -> List[FilePath]:
        """
        Unzips and uploads files for each date in the date range.

        Returns:
            List of FilePath objects for the extracted files

        Raises:
            ValueError: If no files were successfully processed
        """
        start_date = self.config_parser.start_date
        end_date = self.config_parser.end_date

        logger.info(f"Processing date range from {start_date} to {end_date}")

        # Iterate through the date range
        current_date = start_date
        unzip_folder_paths = []
        errors = []

        while current_date <= end_date:
            try:
                unzip_folder_paths.append(self._unzip_and_upload_file(current_date))
            except Exception as e:
                logger.error(f"Error processing date {current_date}: {str(e)}")
                errors.append(f"{current_date}: {str(e)}")

            current_date += timedelta(days=1)

        if not unzip_folder_paths:
            error_msg = f"No files were successfully processed. Errors: {', '.join(errors)}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.info(f"Successfully processed {len(unzip_folder_paths)} files")
        return unzip_folder_paths

    def discover_source_files(self, source: JobS3Params) -> List[FilePath]:
        """
        Discovers source files in S3 bucket based on file pattern and date range.
        Iterates from start_date to end_date to find files matching the pattern.

        Args:
            source: JobS3Params object containing S3 parameters

        Returns:
            List of FilePath objects for discovered files

        Raises:
            ValueError: If no files are found or if parameters are invalid
        """
        start_date = self.config_parser.start_date
        end_date = self.config_parser.end_date

        logger.info(f"Discovering source files from {start_date} to {end_date}")

        if not source.bucket or not source.prefix:
            raise ValueError("Bucket and prefix must be specified in source parameters.")

        if not source.file_pattern:
            raise ValueError("File pattern must be specified for file discovery.")

        discovered_files = []
        errors = []
        current_date = start_date

        while current_date <= end_date:
            try:
                # Build the expected file path using the date
                file_key = self.build_s3_path_prefix(source, current_date)
                
                # Check if file exists in S3
                try:
                    self.s3_client.head_object(Bucket=source.bucket, Key=file_key)
                    discovered_files.append(FilePath(source.bucket, file_key))
                    logger.info(f"Found file: s3://{source.bucket}/{file_key}")
                except ClientError as e:
                    if e.response['Error']['Code'] == '404':
                        logger.warning(f"File not found: s3://{source.bucket}/{file_key}")
                        errors.append(f"{current_date}: File not found")
                    else:
                        raise

            except Exception as e:
                logger.error(f"Error processing date {current_date}: {str(e)}")
                errors.append(f"{current_date}: {str(e)}")

            current_date += timedelta(days=1)

        if not discovered_files:
            error_msg = f"No files discovered in date range. Errors: {', '.join(errors)}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.info(f"Successfully discovered {len(discovered_files)} files")
        return discovered_files

