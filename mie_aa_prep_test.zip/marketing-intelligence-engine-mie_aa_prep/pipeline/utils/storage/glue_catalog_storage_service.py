import logging
from datetime import timedelta
from typing import Any, Dict
from pyspark.sql import DataFrame

from config_parser import ConfigParser
from entities.job_config import JobS3Params
from constants import YEAR, MONTH, DAY
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame

logger = logging.getLogger(__name__)


class GlueCatalogStorageService:
    """
    Class for interacting with AWS Glue Catalog to read tables.
    """

    def __init__(self):
        """
        Initialize the GlueCatalogStorage with a Glue context.

        Args:
            glue_context: The Glue context to use for reading tables
        """
        self.config_parser = ConfigParser()
        self.glue_context = self.config_parser.glue_context
        logger.info("Initialized GlueCatalogStorageService with Glue context.")

    def get_year_month_day_partition(self) -> Dict[str, list[str]]:
        current_date = self.config_parser.start_date
        end_date = self.config_parser.end_date
        partition_value_map: Dict[str, Any] = {
            "year": [],
            "month": [],
            "day": []
        }
        while current_date <= end_date:
            year = current_date.strftime(YEAR)
            month = current_date.strftime(MONTH)
            day = current_date.strftime(DAY)
            if year not in partition_value_map["year"]:
                partition_value_map["year"].append(year)
            if month not in partition_value_map["month"]:
                partition_value_map["month"].append(month)
            if day not in partition_value_map["day"]:
                partition_value_map["day"].append(day)
            current_date = current_date + timedelta(days=1)
        logger.info(f"Generated partition values: {partition_value_map}")
        return partition_value_map

    def read_table(self, source: JobS3Params) -> DataFrame:
        """
        Read a table from the Glue Catalog and return it as a DataFrame.

        Args:
            source: JobS3Params containing database and table information

        Returns:
            DataFrame: The table data as a Spark DataFrame
        """
        database_name = source.database
        table_name = source.table

        if not database_name or not table_name:
            logger.error("Both database_name and table_name must be provided in JobS3Params")
            raise ValueError("Both database_name and table_name must be provided in JobS3Params")

        logger.info(f"Reading table '{table_name}' from database '{database_name}'.")

        dy_frame = self.glue_context.create_dynamic_frame.from_catalog(
            database=database_name,
            table_name=table_name
        )
        df = dy_frame.toDF()  # This warning is expected in AWS Glue and can be safely ignored
        unknown_partition = []
        if source.partition and 'by' in source.partition:
            partition_columns = source.partition['by']
            logger.info(f"Filtering DataFrame by partitions: {partition_columns}")
            partition_values = self.get_year_month_day_partition()
            for column in partition_columns:
                if column == 'year':
                    year_values = partition_values['year']
                    df = df.filter(df[column].isin(year_values))
                elif column == 'month':
                    month_values = partition_values['month']
                    df = df.filter(df[column].isin(month_values))
                elif column == 'day':
                    day_values = partition_values['day']
                    df = df.filter(df[column].isin(day_values))
                else:
                    unknown_partition.append(column)
            if unknown_partition:
                logger.error(f"Unknown partition columns: {', '.join(unknown_partition)}")
                raise ValueError(f"Unknown partition columns: {', '.join(unknown_partition)}")
        logger.info("Table read and filtered successfully.")
        return df
