import logging
from typing import List, Optional
import boto3
from botocore.exceptions import ClientError
from pyspark.sql import DataFrame
from pyspark.sql.functions import input_file_name, to_date
from config_parser import ConfigParser
from entities.job_config import JobS3Params
from constants import FileType, Compression

# Import schema module
from schema import ADOBE_COLUMNS, get_adobe_schema

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FilePath:
    """
    Represents a file path in S3 with bucket and key.
    """

    def __init__(self, bucket: str, key: str):
        """
        Initialize with S3 bucket and key.

        Args:
            bucket: S3 bucket name
            key: S3 object key (path)
        """
        self.bucket = bucket
        self.key = key

    @property
    def s3_path(self) -> str:
        """
        Get the full S3 path in the format s3://bucket/key.

        Returns:
            S3 path as a string
        """
        return f"s3://{self.bucket}/{self.key}"


class StorageS3Service:
    """
    Service for interacting with S3 storage.
    """

    def __init__(self, region_name: str = "us-east-1"):
        """
        Initialize the S3 service with AWS region.

        Args:
            region_name: AWS region name, defaults to us-east-1
        """
        try:
            self.s3_client = boto3.client("s3", region_name=region_name)
            self.config_parser = ConfigParser()
            logger.info("S3 service initialized")
        except Exception as e:
            logger.error(f"Failed to initialize S3 service: {str(e)}")
            raise

    @staticmethod
    def folder_exists(bucket_name, path_to_folder):
        try:
            s3 = boto3.client('s3')
            res = s3.list_objects_v2(
                Bucket=bucket_name,
                Prefix=path_to_folder
            )
            return 'Contents' in res
        except ClientError as e:
            # Logic to handle errors.
            logger.error(f"Error checking folder existence: {str(e)}")
            raise e

    def read_csv_file_paths(self, source: JobS3Params, file_paths: List[FilePath], use_schema: bool = False) -> DataFrame:
        """
        Reads CSV/TSV files from S3 as a Spark DataFrame.
        Uses comma separator for CSV and tab separator for TSV.
        Handles GZIP compression when specified.

        Args:
            file_paths: List of FilePath objects to read
            source: JobS3Params object containing source configuration
            use_schema: Whether to use predefined schema from schema.py

        Returns:
            Spark DataFrame containing the combined data

        Raises:
            ValueError: If no valid S3 paths are provided
            ClientError: For S3 client errors
        """
        file_type_name = "CSV/TSV"
        logger.info(f"Reading {len(file_paths)} {file_type_name} files from S3")

        # Convert list of FilePath objects to list of S3 paths
        s3_paths = []
        error_paths = []

        # Check that each file exists in S3
        for file_path in file_paths:
            try:
                if self.folder_exists(file_path.bucket, file_path.key):
                    s3_paths.append(file_path.s3_path)

                logger.debug(f"Verified file exists: {file_path.s3_path}")
            except ClientError as e:
                if e.response['Error']['Code'] == '404':
                    error_paths.append(file_path.s3_path)
                    logger.warning(f"Folder not found: {file_path.s3_path}")
                else:
                    logger.error(f"Error checking file {file_path.s3_path}: {str(e)}")
                    raise

        if not s3_paths:
            error_msg = f"No valid S3 paths provided for reading {file_type_name} files. Errors: {error_paths}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # build s3 path based on bucket and prefix property from source object.from
        base_path = f"s3://{source.bucket}/{source.prefix}"
        logger.info(f"Reading {len(s3_paths)} valid {file_type_name} files")
        
        # Configure separator based on file type
        separator = ','  # Default for CSV
        if source.file_type == FileType.TSV:
            separator = '\t'  # Tab separator for TSV
        
        # Use schema.py schema if use_schema is True
        if use_schema:
            logger.info("Using predefined schema with all string columns")
            reader = self.config_parser.spark.read.format('csv') \
                .option('basePath', base_path) \
                .option('header', 'false') \
                .option('inferSchema', 'false') \
                .option('sep', separator) \
                .schema(get_adobe_schema())
        else:
            # Original behavior with inferSchema and header
            reader = self.config_parser.spark.read.format('csv') \
                .option('basePath', base_path) \
                .option('header', 'true') \
                .option('inferSchema', 'true') \
                .option('sep', separator)
            
        # Add compression option if GZIP compression is specified
        if hasattr(source, 'compression') and source.compression == Compression.GZIP:
            logger.info("Adding GZIP compression option for reading")
            reader = reader.option('compression', 'gzip')
            
        return reader.load(s3_paths)

    def read_data(self, source: JobS3Params, file_paths: List[FilePath] = None, use_schema: bool = False) -> DataFrame:
        """
        Reads data from S3 based on the file type and provided paths.

        Args:
            source: JobS3Params object containing source configuration
            file_paths: Optional list of specific file paths to read
            use_schema: Whether to use predefined schema from schema.py

        Returns:
            Spark DataFrame containing the read data

        Raises:
            ValueError: If file type is not supported or no paths provided
        """
        if file_paths is None:
            file_paths = []

        logger.info(f"Reading data from S3 with file type: {source.file_type}")

        if source.file_type == FileType.CSV or source.file_type == FileType.TSV:
            if len(file_paths) > 0:
                df = self.read_csv_file_paths(source, file_paths, use_schema)

            else:
                # Implementation for reading from a date range
                raise ValueError("Reading from date range is not implemented. Please provide file paths.")
        else:
            error_msg = f"Unsupported file type: {source.file_type}. Supported types: CSV, TSV"
            logger.error(error_msg)
            raise ValueError(error_msg)

        df = df.withColumn("filepath", input_file_name())
        df.printSchema()
        return df

    def write_data(self, data: DataFrame, destination: JobS3Params) -> None:
        """
        Write data to S3 in the specified format.

        Args:
            data (DataFrame): The data to write
            destination (JobS3Parameter): S3 destination configuration

        Raises:
            ValueError: If the file type is not supported
            Exception: For other issues during S3 operations
        """
        try:

            file_path = FilePath(destination.bucket, destination.prefix)
            logger.info(f"Writing data to {file_path.s3_path}")

            write_options = self._get_write_options(destination)
            logger.info(f"Write options: {write_options}")
            if destination.file_type == FileType.PARQUET:
                self._write_parquet(data, file_path.s3_path, write_options)

            logger.info(f"Successfully wrote data to {file_path.s3_path}")
        except Exception as e:
            logger.error(f"Error writing data to S3: {str(e)}")
            raise

    @staticmethod
    def _write_parquet(data: DataFrame, path: str, options: dict[str, any]) -> None:
        """
        Write data to S3 in Parquet format.

        Args:
            data (DataFrame): The data to write
            path (str): The S3 path to write to
            options (Dict[str, Any]): Write options
            mode (str): Write mode (overwrite, append, etc.)
        """
        database = options.pop('database')
        table = options.pop('table')

        data.printSchema()
        mode = options.pop('mode')
        logger.info(f"Writing data to S3 in Parquet format at {path} with mode {mode}")
        writer = data.write.mode(mode)

        # Apply partitioning if specified
        if 'partition_by' in options:
            partition_columns = options.pop('partition_by')
            logger.info(f"Partitioning data by columns: {partition_columns}")
            writer = writer.partitionBy(*partition_columns)

        # Apply options
        logger.info(f"Applying write options: {options}")
        for key, value in options.items():
            writer = writer.option(key, value)
        logger.info(f"Writing data to S3 at {path} in Parquet format")
        # compression="snappy"
        writer.option('path', path).saveAsTable(f"`{database}`.`{table}`")

        logger.info(f"Data successfully written to {path} in Parquet format")

    @staticmethod
    def _get_write_options(destination: JobS3Params) -> dict[str, any]:
        """
        Get write options based on the destination configuration.

        Args:
            destination (JobS3Parameter): S3 destination configuration

        Returns:
            Dict[str, Any]: Write options
        """
        options = {}

        # Common options
        if hasattr(destination, 'options') and destination.options:
            options.update(destination.options)

        # Add partitioning if specified
        if (hasattr(destination, 'partition') and destination.partition
                and destination.partition.get('by', None) is not None):
            options['partition_by'] = destination.partition['by']

        # check table and database exist, else throw error
        if (destination.database is None or destination.table is None or len(destination.database) == 0 or
                len(destination.table) == 0):
            raise ValueError("Glue catalog database and table name is required field to write data into S3 destination")
        else:
            options['database'] = destination.database
            options['table'] = destination.table

        if destination.mode:
            options['mode'] = destination.mode
        else:
            raise ValueError("Mode is required parameter in destination s3 configuration.")

        return options