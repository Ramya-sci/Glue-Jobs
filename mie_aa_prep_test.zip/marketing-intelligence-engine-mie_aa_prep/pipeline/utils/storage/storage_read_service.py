import logging
from typing import Optional, List
from pyspark.sql import DataFrame

from storage.glue_catalog_storage_service import GlueCatalogStorageService
from storage.s3_storage_service import StorageS3Service, FilePath
from config_parser import ConfigParser
from file_handler import FileHandler
from constants import FileType, Compression

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StorageReadService:
    """
    Service for reading data from various storage sources.
    Supports S3 with different file formats and compression types.
    """

    def __init__(self):
        self.config_parser = ConfigParser()
        self.s3_srv = StorageS3Service()
        self.glue_catalog_srv = GlueCatalogStorageService()
        self.file_handler = FileHandler()

    def read(self, use_schema: bool = False) -> DataFrame:
        """
        Read data from the configured source in the job configuration.
        
        Args:
            use_schema: Whether to use predefined schema from schema.py instead of inferSchema

        Returns:
            DataFrame: The data read from the storage source

        Raises:
            ValueError: If the source type is not supported or configuration is invalid
            Exception: For other issues during the read operation
        """
        try:
            source = self.config_parser.job_config.source
            if source.type == 's3':
                logger.info(f"Reading data from S3 source: {source.bucket}/{source.prefix}")
                return self.read_from_s3(use_schema)
            if source.type == 'glue_catalog':
                logger.info("Reading data from Glue Catalog source")
                # Placeholder for Glue Catalog read logic
                return self.glue_catalog_srv.read_table(source)
            else:
                raise ValueError(f"Unsupported source type: {source.type}. Only 's3' is currently supported.")
        except Exception as e:
            logger.error(f"Error reading data from storage: {str(e)}")
            raise

    def read_from_s3(self, use_schema: bool = False) -> DataFrame:
        """
        Read data from S3 based on job configuration.
        Handles ZIP compression by extracting files first.
        For other compressions, discovers source files directly.
        
        Args:
            use_schema: Whether to use predefined schema from schema.py instead of inferSchema

        Returns:
            DataFrame: The data read from S3

        Raises:
            ValueError: If configuration is invalid or extraction fails
            Exception: For other issues during S3 operations
        """
        source = self.config_parser.job_config.source
        file_paths: List[FilePath] = []

        # Handle ZIP compression
        if source.compression == Compression.ZIP:
            logger.info("ZIP compression detected, extracting files")
            extracted = self.config_parser.job_config.extracted
            if not extracted:
                raise ValueError("No extracted parameters found in job configuration for ZIP handling.")

            file_paths = self.file_handler.unzip_and_upload()
            source = extracted
            logger.info(f"Using {len(file_paths)} extracted files for processing")
        else:
            # For other compressions, call discover_source_files function to discover list of files in s3 bucket
            logger.info("Discovering source files for non-ZIP compression")
            file_paths = self.file_handler.discover_source_files(source)
            logger.info(f"Discovered {len(file_paths)} files for processing")

        # Read data based on file type
        if source.file_type == FileType.CSV or source.file_type == FileType.TSV:
            if use_schema:
                logger.info("Using predefined schema with all string columns for reading data")
            return self.s3_srv.read_data(source, file_paths, use_schema)
        else:
            raise ValueError(f"Unsupported file type: {source.file_type}. Supported types: CSV, TSV")