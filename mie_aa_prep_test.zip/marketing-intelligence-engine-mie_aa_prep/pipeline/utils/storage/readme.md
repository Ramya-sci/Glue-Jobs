# Glue Catalog Storage Service
1. Create class name GlueCatalogStorage
2. Implement the following methods:
   - `__init__(self)`
   - `read_table(self, source: JobS3Params) -> DataFrame`
3. init method should accept glue context
4. read_table method should read a table from Glue Catalog and return a DataFrame


# Redshift Storage Service
1. Create class name RedshiftStorage
2. Implement the following methods:
3. `__init__(self)`: 
   - Initialize the database name, schema name and table name properties from config_parser.job_config
4. `write_table(self, df: DataFrame) -> None`
   - Write the DataFrame to Redshift table using write_dynamic_frame.from_options
   - Use the following options:
     - `connection_type`: 'redshift'
     - `connection_options`: {
         'dbtable': f"{self.schema_name}.{self.table_name}",
         'database': self.database_name,
     - 'useConnectionProperties': True
     - 'connection_name': '{connection_name}',
     - 'redshiftTmpDir': 's3://{bucket_name}/tmp/'
       }

     - transformation_ctx="redshift_sink"
5. upsert_table(self, df: DataFrame, destination: JobS3Params) -> None
   - create new column in df named _surrogate_key with md5 hash of the concatenation of all merge columns defined in destination object
   - Generate SQL query to create a temporary table copying destination.table structure as preaction sql query
   - Generate SQL query to update data based on _surrogate_key into target table from staging table
   - Generate SQL query to insert new data into target table from staging table
   - Join update and insert queries with semicolon name it as `postactions` query
   - write the DataFrame to the temporary table using write_dynamic_frame.from_options and pass the preaction sql query as `preactions` option
     a. pass postactions query as `postactions` options
   - Use destination object to get table, database and schema names