import logging
from typing import Optional
from pyspark.sql import DataFrame
from pyspark.sql.functions import current_date, lit
from pyspark.sql.types import DateType

from storage.redshift_storage_service import RedshiftStorageService
from storage.s3_storage_service import StorageS3Service
from config_parser import ConfigParser
from constants import FileType

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StorageWriteService:
    """
    Service for writing data to various storage destinations.
    Supports S3 with different file formats.
    """

    def __init__(self):
        self.s3_srv = StorageS3Service()
        self.config_parser = ConfigParser()
        self.redshift_srv = RedshiftStorageService()  # Placeholder for Redshift service, to be implemented

    def write(self, data: DataFrame) -> None:
        """
        Write data to the configured destination in the job configuration.

        Args:
            data (DataFrame): The data to write to the storage destination

        Raises:
            ValueError: If the destination type is not supported or configuration is invalid
            Exception: For other issues during the write operation
        """
        try:
            destination = self.config_parser.job_config.destination
            if destination.type == 's3':
                logger.info(f"Writing data to S3 destination: {destination.bucket}/{destination.prefix}")
                self.write_to_s3(data)
            elif destination.type == 'redshift':
                logger.info("Writing data to Redshift destination")
                # Placeholder for Redshift write logic
                self.redshift_srv.upsert_table(data, destination)
            else:
                raise ValueError(f"Unsupported destination type: {destination.type}. Only 's3' and 'redshift' is currently supported.")
        except Exception as e:
            logger.error(f"Error writing data to storage: {str(e)}")
            raise e

    def write_to_s3(self, data: DataFrame) -> None:
        """
        Write data to S3 based on job configuration.

        Args:
            data (DataFrame): The data to write to S3

        Raises:
            ValueError: If configuration is invalid
            Exception: For other issues during S3 operations
        """
        destination = self.config_parser.job_config.destination

        # Write data based on file type
        if destination.file_type == FileType.PARQUET:
            # add insert_dt and update_dt columns if they are not present
            if 'insert_dt' not in data.columns:
                # insert date is the current date
                data = data.withColumn('insert_dt', current_date())
            if 'update_dt' not in data.columns:
                # update date is the current date
                data = data.withColumn('update_dt', lit(None).cast(DateType()))

            self.s3_srv.write_data(data, destination)
        else:
            raise ValueError(f"Unsupported file type for writing: {destination.file_type}. Supported types are CSV and PARQUET.")

