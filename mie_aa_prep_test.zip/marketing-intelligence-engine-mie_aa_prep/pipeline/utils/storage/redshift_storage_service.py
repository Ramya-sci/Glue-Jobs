from typing import Dict, Any, List
from pyspark.sql import DataFrame
from awsglue.dynamicframe import DynamicFrame
import logging
import boto3
import time
import hashlib
from pyspark.sql.functions import md5, concat_ws, col, lit

from config_parser import ConfigParser
from constants import GLUE_ASSETS_DIR, CONNECTION_MAP
from entities.job_config import JobS3Params

logger = logging.getLogger(__name__)


class RedshiftStorageService:
    """
    Class for interacting with AWS Redshift to write data.
    """

    def __init__(self):
        """
        Initialize the RedshiftStorage with database, schema, and table names from config.

        Args:
            config_parser: Configuration parser containing job configuration
        """
        self.config_parser = ConfigParser()
        self.glue_context = self.config_parser.glue_context
        self.glue_client = boto3.client('glue')

    def write_table(self, destination: JobS3Params, df: DataFrame) -> None:
        """
        Write a DataFrame to a Redshift table.
        If merge_columns are specified, performs an upsert operation.

        Args:
            destination: JobS3Params containing destination configuration
            df: DataFrame to write
        """
        if not df.count():
            logger.info("DataFrame is empty. Skipping write operation.")
            return

        # Direct write method only (upsert implementation removed as requested)
        self._write_table_direct(destination, df)

    def _write_table_direct(self, destination: JobS3Params, df: DataFrame) -> None:
        """
        Write a DataFrame directly to a Redshift table without upsert logic.

        Args:
            destination: JobS3Params containing destination configuration
            df: DataFrame to write
        """
        dynamic_frame = DynamicFrame.fromDF(df, self.glue_context, "dynamic_frame")

        # Print debug information
        logger.info(f"Writing DataFrame to Redshift table: {destination.schema}.{destination.table} in database {destination.database}")

        connection_name = CONNECTION_MAP.get(destination.database, None)
        logger.info(f"connection_name={connection_name}")

        connection_options = {
            'dbtable': f"{destination.schema}.{destination.table}",
            'database': destination.database,
            'useConnectionProperties': True,
            'connectionName': connection_name,
            'redshiftTmpDir': GLUE_ASSETS_DIR
        }
        try:
            self.glue_context.write_dynamic_frame.from_options(
                frame=dynamic_frame,
                connection_type='redshift',
                connection_options=connection_options,
                transformation_ctx="redshift_sink",
            )
        except Exception as e:
            logger.error(f"Error writing DataFrame to Redshift: {str(e)}")
            raise e

    def upsert_table(self, df: DataFrame, destination: JobS3Params) -> None:
        """
        Perform an upsert operation on a Redshift table using a staging table approach.

        Args:
            df: DataFrame to upsert
            destination: JobS3Params containing destination configuration including merge columns
        """
        if not df.count():
            logger.info("DataFrame is empty. Skipping upsert operation.")
            return

        if not destination.merge_columns:
            logger.warning("No merge columns specified. Falling back to direct write.")
            self._write_table_direct(destination, df)
            return

        logger.info(f"Performing upsert operation to {destination.schema}.{destination.table} based on merge columns: {destination.merge_columns}")

        # Create a surrogate key by concatenating all merge columns and computing MD5 hash
        concat_columns = concat_ws('|', *[col(c) for c in destination.merge_columns])
        df_with_key = df.withColumn("_surrogate_key", md5(concat_columns))

        # Generate a unique name for the temporary table
        temp_table = f"{destination.table}_tmp_{int(time.time())}"
        full_temp_table = f"{destination.schema}.{temp_table}"
        full_target_table = f"{destination.schema}.{destination.table}"

        # Generate SQL to create temporary table with same structure as target
        preactions_sql = f"CREATE TABLE IF NOT EXISTS {full_temp_table} (LIKE {full_target_table});"

        # Prepare the list of columns for SQL statements (excluding surrogate key)
        all_columns = [column for column in df.columns if column != "_surrogate_key"]
        columns_names = ", ".join(all_columns)
        all_source_columns = [f"s.{column}" for column in all_columns]
        source_columns_names = ", ".join(all_source_columns)
        set_columns = ", ".join([f"{column} = source.{column}" for column in all_columns])
        begin_sql = f"BEGIN"
        # Generate SQL for update statement
        update_sql = (f"UPDATE {full_target_table} target SET {set_columns}, update_dt = CURRENT_TIMESTAMP"
                      f" FROM {full_temp_table} source WHERE target._surrogate_key = source._surrogate_key")

        # Generate SQL for insert statement to add new records
        insert_sql = (f"INSERT INTO {full_target_table} ({columns_names}, _surrogate_key) "
                      f"SELECT {source_columns_names}, s._surrogate_key FROM {full_temp_table} s LEFT JOIN {full_target_table} t"
                      f" ON s._surrogate_key = t._surrogate_key WHERE t._surrogate_key IS NULL"
                      )
        drop_temp_table_sql = f"DROP TABLE IF EXISTS {full_temp_table}"
        commit = f"COMMIT"

        # Combine update and insert as postactions
        postactions_sql = f"{begin_sql}; {update_sql}; {insert_sql}; {drop_temp_table_sql}; {commit};"
        # remove newlines for Redshift compatibility
        preactions_sql = preactions_sql.replace('\n', '')
        postactions_sql = postactions_sql.replace('\n', '')
        preactions_sql_print = preactions_sql.replace(';', ';\n')
        postactions_sql_print = postactions_sql.replace(';', ';\n')
        logger.info(f"Preactions SQL: {preactions_sql_print}")
        logger.info(f"Postactions SQL: {postactions_sql_print}")


        # Convert to DynamicFrame
        dynamic_frame = DynamicFrame.fromDF(df_with_key, self.glue_context, "dynamic_frame_with_key")

        connection_name = CONNECTION_MAP.get(destination.database, None)

        # Write to the temporary table with pre/post actions
        connection_options = {
            'dbtable': full_temp_table,
            'database': destination.database,
            'useConnectionProperties': True,
            'connectionName': connection_name,
            'redshiftTmpDir': GLUE_ASSETS_DIR,
            'preactions': preactions_sql,
            'postactions': postactions_sql
        }

        try:
            logger.info(f"Executing upsert operation with temporary table {full_temp_table}")
            self.glue_context.write_dynamic_frame.from_options(
                frame=dynamic_frame,
                connection_type='redshift',
                connection_options=connection_options,
                transformation_ctx="redshift_upsert"
            )
            logger.info("Upsert operation completed successfully")
        except Exception as e:
            logger.error(f"Error during upsert operation: {str(e)}")
            raise e
