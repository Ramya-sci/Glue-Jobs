import logging
from datetime import datetime
from typing import Optional, Dict, Any

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

from constants import JobStatus, JOBS_TABLE, JOBS_STATUS_TABLE, DAY_FORMAT, HOURLY_FORMAT
from entities.job_config import JobConfig
from entities.job_run import JobRun

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DynamodbHandler:
    """
    Handler for interacting with DynamoDB tables storing job configurations and run history.
    """

    def __init__(self):
        """
        Initializes the DynamoDB handler by connecting to the AWS DynamoDB service.
        """
        try:
            my_session = boto3.session.Session()
            self.dynamodb = boto3.resource('dynamodb', region_name=my_session.region_name)
            self.job_config_table = self.dynamodb.Table(JOBS_TABLE)
            self.job_run_history_table = self.dynamodb.Table(JOBS_STATUS_TABLE)
            logger.info(f"DynamoDB handler initialized for tables: {JOBS_TABLE}, {JOBS_STATUS_TABLE}")
        except ClientError as e:
            logger.error(f"Failed to initialize DynamoDB connection: {str(e)}")
            raise

    def get_job_config(self, job_id: str) -> JobConfig:
        """
        Reads job configuration from 'mie_job_config' table.

        Args:
            job_id: The job identifier

        Returns:
            JobConfig object with the job configuration

        Raises:
            ValueError: If job_id not found
            ClientError: For DynamoDB client errors
        """
        try:
            logger.info(f"Fetching job configuration for job_id: {job_id}")
            response = self.job_config_table.get_item(
                Key={'job_id': job_id}
            )

            if 'Item' not in response:
                logger.error(f"Job configuration not found for job_id: {job_id}")
                raise ValueError(f"Job configuration for job_id {job_id} not found.")

            item = response['Item']
            logger.info(f"Found job configuration: {item.get('job_name', 'unnamed')}")

            # Create a new config object with all properties
            job_config = {
                'job_id': item['job_id'],
                'job_name': item.get('job_name'),
                'start_date_offset': int(item.get('start_date_offset', 0)),
                'end_date_offset': int(item.get('end_date_offset', 0)),
                'dependency': item.get('dependency'),
                'source': item.get('source'),
                'extracted': item.get('extracted'),
                'destination': item.get('destination')
            }

            return JobConfig().set_job_config(job_config)

        except ClientError as e:
            logger.error(f"DynamoDB error fetching job configuration: {str(e)}")
            raise

    def get_job_run(self, job_id: str) -> Optional[JobRun]:
        """
        Reads the most recent completed job run for the specified job_id.

        Args:
            job_id: The job identifier

        Returns:
            JobRun object or None if no completed runs found

        Raises:
            ClientError: For DynamoDB client errors
        """
        try:
            logger.info(f"Fetching latest completed job run for job_id: {job_id}")
            response = self.job_run_history_table.query(
                KeyConditionExpression=Key('job_id').eq(job_id),
                FilterExpression=Key('status').eq(JobStatus.COMPLETED.value),
                ScanIndexForward=False,  # Descending order
                Limit=1  # Get only the latest run
            )

            if 'Items' not in response or len(response['Items']) == 0:
                logger.info(f"No completed job runs found for job_id: {job_id}")
                return None

            item = response['Items'][0]
            logger.info(f"Found latest job run from: {item.get('last_process_date')}")

            job_run = {
                'job_id': item['job_id'],
                'last_process_date': item.get('last_process_date', None),
                'run_id': item.get('run_id'),
                'start_date': item.get('start_date'),
                'end_date': item.get('end_date'),
                'historical_refill': item.get('historical_refill', False),
                'status': item.get('status'),
            }
            job_run_obj = JobRun()
            job_run_obj.set_job_run(job_run)
            return job_run_obj

        except ClientError as e:
            logger.error(f"DynamoDB error fetching job run: {str(e)}")
            raise

    def store_job_run(self, job_run: JobRun) -> bool:
        """
        Stores job run status information in the job run history table.

        Args:
            job_run: JobRun object containing the job run details

        Returns:
            bool: True if successfully stored, False otherwise

        Raises:
            ClientError: For DynamoDB client errors
        """
        try:
            logger.info(f"Storing job run status for job_id: {job_run.job_id}")
            item = job_run.get_job_run_dict()

            logger.info(f"Preparing to store job run item: {item}")
            # Store the item in DynamoDB
            self.job_run_history_table.put_item(Item=item)
            logger.info(f"Successfully stored job run status for job_id: {job_run.job_id}, status: {item['status']}")
            return True

        except ClientError as e:
            logger.error(f"DynamoDB error storing job run status: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error storing job run status: {str(e)}")
            return False
