from datetime import datetime

from constants import DAY_FORMAT, HOURLY_FORMAT, JobStatus


class JobRun:
    def __init__(self):
        self.job_id = ''
        self.last_process_date = None
        self.run_id = None
        self.historical_refill = None
        self.start_date = None
        self.end_date = None
        self.status = None

    def set_job_run(self, job_run: dict):
        # Sets properties from job_run dictionary
        self.last_process_date = self.set_date_time(job_run.get('last_process_date', None), HOURLY_FORMAT)
        self.start_date = self.set_date_time(job_run.get('start_date', None), DAY_FORMAT)
        self.end_date = self.set_date_time(job_run.get('end_date', None), DAY_FORMAT)
        self.job_id = job_run.get('job_id', '')
        self.run_id = job_run.get('run_id', None)
        self.historical_refill = job_run.get('historical_refill', False)
        self.set_status(job_run.get('status', None))

    @staticmethod
    def set_date_time(timestamp: str | datetime | None, date_format: str = HOURLY_FORMAT):
        # Sets the last executed timestamp of the job run
        if isinstance(timestamp, str):
            return datetime.strptime(timestamp, date_format)
        elif isinstance(timestamp, datetime):
            return timestamp
        else:
            return None

    def set_status(self, status: str | JobStatus | None):
        # Sets the status of the job run

        if isinstance(status, str):
            # If status is a string, convert it to JobStatus enum
            try:
                self.status = JobStatus[status.upper()]
            except KeyError:
                raise ValueError(f"Invalid job status: {status}")
        elif isinstance(status, JobStatus):
            self.status = status
        else:
            # If status is None or not provided, set it to None
            self.status = None

    def get_job_run_dict(self):
        # Returns a dictionary representation of the job run
        return {
            'job_id': self.job_id,
            'last_process_date': self.last_process_date.strftime(HOURLY_FORMAT) if self.last_process_date else None,
            'start_date': self.start_date.strftime(DAY_FORMAT) if self.start_date else None,
            'end_date': self.end_date.strftime(DAY_FORMAT) if self.end_date else None,
            'run_id': self.run_id,
            'historical_refill': self.historical_refill,
            'status': self.status.value if self.status else None
        }
