from constants import FileType, Compression


class JobConfig:
    def __init__(self):
        self.job_id = ''
        self.job_name = None
        self.dependency = None
        self.start_date_offset = None
        self.end_date_offset = None
        self.source = None
        self.extracted = None
        self.destination = None

    def set_job_config(self, job_config: dict):
        """
        # Sets properties from job_config dictionary
        """
        self.job_id = job_config.get('job_id', None)
        self.job_name = job_config.get('job_name', None)
        self.start_date_offset = job_config.get('start_date_offset', 1)
        self.end_date_offset = job_config.get('end_date_offset', 1)
        self.dependency = job_config.get('dependency', None)
        # Set source configuration using JobS3Params
        self.source = JobS3Params().set_params(job_config.get('source'))

        # Set extracted configuration using JobS3Params
        extracted = job_config.get('extracted', None)
        if extracted is not None:
            self.extracted = JobS3Params().set_params(extracted)

        # Set destination configuration using JobS3Params
        self.destination = JobS3Params().set_params(job_config.get('destination'))

        return self

    def get_config_dict(self):
        """
        # Returns a dictionary representation of the job config
        """
        config_dict = {
            'job_id': self.job_id,
            'job_name': self.job_name,
            'start_date_offset': self.start_date_offset,
            'end_date_offset': self.end_date_offset,
            'dependency': self.dependency,
        }

        # Add non-empty parameter dictionaries
        source_dict = self.source.get_params_dict()
        if source_dict:
            config_dict['source'] = source_dict
        if self.extracted:
            config_dict['extracted'] = self.extracted.get_params_dict()

        destination_dict = self.destination.get_params_dict()
        if destination_dict:
            config_dict['destination'] = destination_dict

        return config_dict


class JobS3Params:
    """
    Generic class for storing S3 parameters for job configuration
    """

    def __init__(self):
        self.type = None
        self.bucket = None
        self.prefix = None
        self.file_pattern = None
        self.file_type = None
        self.compression = None
        self.database = None
        self.table = None
        self.partition = None
        self.mode = None
        # write options
        self.options = None
        # schema property
        self.schema = None
        self.merge_columns = None
        self.date_column = None
        self.table_type = None

    def set_params(self, params: dict | None):
        """
        Sets parameters from dictionary
        """
        if not params:
            return self

        self.type = params.get('type')
        self.bucket = params.get('bucket')
        self.prefix = params.get('prefix')
        self.file_pattern = params.get('file_pattern')
        if 'file_type' in params:
            # if file_type is not supported, it will raise ValueError
            if isinstance(params['file_type'], str) and params['file_type'].upper() not in FileType.__members__:
                raise ValueError(f"Unsupported file type: {params['file_type']}")

            self.file_type = FileType(params['file_type'])
        self.database = params.get('database')
        self.table = params.get('table')
        self.partition = params.get('partition')
        self.mode = params.get('mode')
        self.options = params.get('options')
        self.merge_columns = params.get('merge_columns')
        self.schema = params.get('schema')
        self.date_column = params.get('date_column')
        self.table_type = params.get('table_type')
        if 'compression' in params:
            # if compression is not supported, it will raise ValueError
            if isinstance(params['compression'], str) and params['compression'].upper() not in Compression.__members__:
                raise ValueError(f"Unsupported compression type: {params['compression'].upper()}")
            self.compression = Compression(params['compression'])
        return self

    def get_params_dict(self):
        """
        Returns a dictionary representation of the parameters
        """
        params_dict = {}

        if self.type:
            params_dict['type'] = self.type
        if self.bucket:
            params_dict['bucket'] = self.bucket
        if self.prefix:
            params_dict['prefix'] = self.prefix
        if self.file_pattern:
            params_dict['file_pattern'] = self.file_pattern
        if self.file_type:
            params_dict['file_type'] = self.file_type.value
        if self.database:
            params_dict['database'] = self.database
        if self.table:
            params_dict['table'] = self.table
        if self.partition:
            params_dict['partition'] = self.partition
        if self.compression:
            params_dict['compression'] = self.compression.value
        if self.schema:
            params_dict['schema'] = self.schema
        if self.merge_columns:
            params_dict['merge_columns'] = self.merge_columns
        if self.table_type:
            params_dict['table_type'] = self.table_type
        if self.date_column:
            params_dict['date_column'] = self.date_column
        return params_dict
