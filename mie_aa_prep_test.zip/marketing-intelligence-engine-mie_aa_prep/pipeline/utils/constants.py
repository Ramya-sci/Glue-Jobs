from enum import Enum
import os

DAY_FORMAT = '%Y-%m-%d'
HOURLY_FORMAT = '%Y-%m-%d %H:%M:%S'
DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
YEAR = "%Y"
MONTH = "%m"
DAY = "%d"

JOBS_TABLE = 'mie_job_config'
JOBS_STATUS_TABLE = 'mie_job_run_history'

GLUE_ASSETS_DIR = "s3://aws-glue-assets-873109961464-us-west-2/temporary/"

# Set Environment based on the environment variable
ENVIRONMENT = 'development'  # Default to development if not set
if 'ENVIRONMENT' in os.environ:
    ENVIRONMENT = os.environ['ENVIRONMENT'].lower()

# Job status
class JobStatus(Enum):
    RUNNING = 'RUNNING'
    COMPLETED = 'COMPLETED'
    FAILED = 'FAILED'
    CANCELLED = 'CANCELLED'


# file types
class FileType(Enum):
    CSV = 'csv'
    TSV = 'tsv'
    JSON = 'json'
    PARQUET = 'parquet'


class Compression(Enum):
    ZIP = 'zip'
    GZIP = 'gzip'


CONNECTION_MAP = {
    "stage": f"svcmie-marketing-{ENVIRONMENT}-stage",
    "lake": f"svcmie-marketing-{ENVIRONMENT}-lake",
    "aggregate": f"svcmie-marketing-{ENVIRONMENT}-aggregate"
}
