# TSV Implementation
## Current state
1. storage_read_service.py has ability to read csv which is compressed in zip format.
2. s3_storage_service in pyspark read_data function in S3StorageService class accepts file_paths as input.
    a. In existing implementation file_handler generates the file paths after iterating through zip files.

## References
1. Refer ../adobe_analytics/config.json - 3rd object with mie_aa_desktop_prep as job_id as job_config in config_parser

## Future State
1. file_handler should have new function called discover_source_files(source: JobS3Params) iterate through prefix path specified in job_config.source (JobS3Params) from start_date to end_date.
2. For step 1, ensure files iterated does exist in s3 bucket.  
3. In constants -> FileType add TSV with string `tsv`
4. storage_read_service -> read_from_s3 function perform following two steps, 
   a. other compressions call discover_source_files functions to discover list of files in s3 bucket.
    b. both FileType.CSV and FileType.TSV should call s3_srv.read_data with same parameters
5. s3_storage_service -> read_data should call read_csv_file_paths for both FileType.CSV and FileType.TSV with same parameter
6. s3_storage_service -> read_csv_file_paths perform following two steps,
a. FileType.CSV file use separator as ',' (comma) and for FileType.TSV use separator as '\t'
b. If compression type is Compression.GZIP then add compression option to csv read with value 'gzip' 