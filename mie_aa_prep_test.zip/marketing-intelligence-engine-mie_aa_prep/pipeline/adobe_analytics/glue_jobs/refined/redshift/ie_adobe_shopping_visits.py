import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import col, lower
from awsglue.dynamicframe import DynamicFrame

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Source details
SOURCE_DATABASE = "ie_dev"
SOURCE_TABLE = "adobe_desktop_filter"
TARGET_S3_PATH = "s3://873109961464-lake-refined/intelligence-engine/ie_adobe_shopping_visits/"

# Read from Glue Catalog (as before)
dyf = glueContext.create_dynamic_frame.from_catalog(
    database=SOURCE_DATABASE,
    table_name=SOURCE_TABLE
)

# Filter/transform with Spark DataFrame
df = dyf.toDF()
result_df = (
    df.filter(
        lower(col("post_pagename")).like("select outbound flight%") |
        lower(col("post_pagename")).contains("flex grid") |
        lower(col("post_pagename")).contains("booking grid")
    )
    .select(
        col("year").alias("shop_yr"),
        col("month").alias("shop_mo"),
        col("day").alias("shop_dy"),
        col("datafeed_date").alias("datafeed_dt"),
        col("shop_date_est").alias("shop_date_est_dt"),
        col("memberid").alias("skymiles_customer_id"),
        col("ecid").alias("ec_id"),
        col("adobesessionid").alias("adobe_session_id"),
        col("post_evar44").alias("adobe_last_click_tracking_cd"),
        col("post_pagename").alias("page_name_str"),
        col("post_evar4").alias("origin_city_cd"),
        col("post_evar5").alias("destination_city_cd"),
        col("post_evar3").alias("triptype_str")
    )
)

# (Optional) Write to CSV in S3 for auditing
result_df.write.mode("overwrite").option("header", True).csv(TARGET_S3_PATH)

# Convert back to DynamicFrame for Redshift write
result_dyf = DynamicFrame.fromDF(result_df, glueContext, "result_dyf")

SCHEMA_NAME = "ie_silver"
TABLE_NAME = "adobe_shopping_visit"


# Generate CREATE SCHEMA and CREATE TABLE SQL
def generate_create_schema_and_table_sql(df, schema_name, table_name):
    type_map = {
        "StringType": "VARCHAR(256)",
        "IntegerType": "INT",
        "LongType": "BIGINT",
        "DoubleType": "DOUBLE PRECISION",
        "TimestampType": "TIMESTAMP",
        "BooleanType": "BOOLEAN"
        # expand as needed
    }
    columns = []
    for f in df.schema.fields:
        redshift_type = type_map.get(type(f.dataType).__name__, "VARCHAR(256)")
        columns.append(f"{f.name} {redshift_type}")
    columns_str = ", ".join(columns)
    sql = (
        f"CREATE SCHEMA IF NOT EXISTS {schema_name}; "
        f"DROP TABLE IF EXISTS {schema_name}.{table_name}; "
        f"CREATE TABLE {schema_name}.{table_name} ({columns_str});"
    )
    return sql


preactions_sql = generate_create_schema_and_table_sql(result_df, SCHEMA_NAME, TABLE_NAME)

# Write to Redshift with schema and table creation
glueContext.write_dynamic_frame.from_options(
    frame=result_dyf,
    connection_type="redshift",
    connection_options={
        "dbtable": f"{SCHEMA_NAME}.{TABLE_NAME}",
        "database": "ie",
        "redshiftTmpDir": "s3://aws-glue-assets-873109961464-us-west-2/temporary/",
        "useConnectionProperties": "true",
        "connectionName": "svcie-marketing-development-ie",
        "preactions": preactions_sql
    },
    transformation_ctx="redshift_sink"
)

job.commit()