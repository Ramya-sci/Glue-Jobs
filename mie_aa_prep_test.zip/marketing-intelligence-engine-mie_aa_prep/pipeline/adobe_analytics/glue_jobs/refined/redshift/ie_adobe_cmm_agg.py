
import logging

from pyspark.sql import DataFrame

from config_parser import ConfigParser
from constants import JobStatus
from storage.storage_read_service import StorageReadService
from storage.storage_write_service import StorageWriteService

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

config_parser = ConfigParser()
# Initialize Spark session
logger.info("Initializing Spark session")
sc = config_parser.init_spark()

storage_read_service = StorageReadService()
storage_write_service = StorageWriteService()

df: DataFrame = storage_read_service.read()

# Debug code
df.show(10, truncate=False)

try:
    logger.info("Applying transformations to dataframe")
    df_renamed = (
        df.withColumnRenamed("activity_date", "activity_dt")
        .withColumnRenamed("referring_domains", "referring_domains_str")
        .withColumnRenamed("tracking_code", "tracking_cd")
        .withColumnRenamed("internal_campaign_code", "internal_campaign_cd")
        .withColumnRenamed("unique_visitors", "unique_visitors_ct")
        .withColumnRenamed("visits", "visits_ct")
        .withColumnRenamed("total_time_seconds", "total_time_seconds_num")
        .withColumnRenamed("page_views", "page_views_ct")
        .withColumnRenamed("flight_searches", "flight_searches_ct")
        .withColumnRenamed("internal_campaign_clickthrough", "internal_campaign_clickthrough_ct")
        .withColumnRenamed("skymiles_enrollments", "skymiles_enrollments_ct")
        .withColumnRenamed("file_date", "file_dt")
    )
    transformed_df = df_renamed.select(
        "activity_dt",
        "referring_domains_str",
        "tracking_cd",
        "internal_campaign_cd",
        "unique_visitors_ct",
        "visits_ct",
        "total_time_seconds_num",
        "page_views_ct",
        "flight_searches_ct",
        "internal_campaign_clickthrough_ct",
        "skymiles_enrollments_ct",
        "file_dt"
    )
    # Debug code
    transformed_df.show(10, truncate=False)
    # Write to redshift
    storage_write_service.write(transformed_df)
    config_parser.store_status(JobStatus.COMPLETED)
    logger.info("mie_adobe_cmm_agg transformation and write completed successfully")
except Exception as e:
    logger.error(f"Error during dataframe transformation: {str(e)}")
    config_parser.store_status(JobStatus.FAILED)
    # Raise the exception to propagate it further
    raise e