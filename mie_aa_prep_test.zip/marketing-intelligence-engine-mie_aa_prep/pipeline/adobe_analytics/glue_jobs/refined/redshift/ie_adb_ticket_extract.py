import sys
import traceback
from functools import reduce
from pyspark.context import SparkContext
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lag, when, expr, split, explode, udf
from pyspark.sql.window import Window
from pyspark.sql.types import StringType, DecimalType
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame

# Initialize Glue job
args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# --- Common transformation function ---
def apply_transformations(df, visit_col):
    window_spec = Window.partitionBy("adobe_mc_id").orderBy("hit_time_utc")
    df = df.withColumn("lagged_visit_ticket", lag(visit_col, 1).over(window_spec))
    df = df.withColumn(
        "ticket_delim_processed",
        when(
            (col("lagged_visit_ticket").isNotNull()) &
            (col("lagged_visit_ticket") != "") &
            (col("lagged_visit_ticket") != col(visit_col)) &
            (col("pnr") != ""),
            expr(f"replace({visit_col}, concat(lagged_visit_ticket, '--**--'), '')")
        ).otherwise(col(visit_col))
    )
    df = df.withColumn(
        "cash_revenue",
        when(
            (col("skymiles_used").cast(DecimalType(38, 2)) > 0) &
            (col("total_revenue").cast(DecimalType(38, 2)) > ((col("skymiles_used").cast(DecimalType(38, 2)) / 100) + col("taxes_fees").cast(DecimalType(38, 2)))) &
            col("skymiles_used").isNotNull() &
            col("taxes_fees").isNotNull(),
            col("total_revenue").cast(DecimalType(38, 2)) - (col("skymiles_used").cast(DecimalType(38, 2)) / 100) + col("taxes_fees").cast(DecimalType(38, 2))
        ).when(
            (col("total_revenue").cast(DecimalType(38, 2)) > col("taxes_fees").cast(DecimalType(38, 2))) &
            col("taxes_fees").isNotNull(),
            col("total_revenue").cast(DecimalType(38, 2)) - col("taxes_fees").cast(DecimalType(38, 2))
        ).when(
            col("skymiles_used").isNull() & col("taxes_fees").isNull(),
            col("total_revenue").cast(DecimalType(38, 2))
        )
    )
    df = df.withColumn("tkt_doc_nb", explode(split(col("ticket_delim_processed"), "--\\*\\*--")))
    return df

# --- Load and transform each platform ---
def load_and_transform(table_name, visit_col, trip_type_col, revenue_col):
    df = glueContext.create_dynamic_frame.from_catalog(
        database="ie_dev", table_name=table_name
    ).toDF()
    df = df.select(
        col("year"),
        col("month"),
        col("day"),
        col("datafeed_date"),
        col("hit_time_utc"),
        col("memberid"),
        col("ecid").alias("adobe_mc_id") if "ecid" in df.merge_columns else col("adobe_mc_id"),
        col("adobe_last_click"),
        col("pnr"),
        col("pnr_split_date"),
        col(visit_col).alias("visit_ticket_delim_raw"),
        col(trip_type_col).alias("trip_type"),
        col(revenue_col).alias("total_revenue"),
        col("skymiles_used"),
        col("taxes_fees"),
        col("datafeed_source")
    )
    return apply_transformations(df, "visit_ticket_delim_raw")

desktop = load_and_transform("adobe_desktop_filter", "post_mvvar2", "trip_type_desktop", "total_revenue_desktop")
iphone = load_and_transform("adobe_iphone_filter", "post_mvvar1", "trip_type_iphone", "total_revenue_iphone")
android = load_and_transform("adobe_android_filter", "post_mvvar1", "trip_type_android", "total_revenue_android")

# --- Union all ---
def unionAll(*dfs):
    return reduce(DataFrame.unionByName, dfs)

final_df = unionAll(desktop, iphone, android)

# --- Final column selection and type casting ---
final_df = final_df.select(
    col("year").cast("int").alias("data_feed_yr"),
    col("month").cast("int").alias("data_feed_mo"),
    col("day").cast("int").alias("data_feed_day"),
    col("datafeed_date").cast("date").alias("data_feed_dt"),
    col("hit_time_utc").cast("timestamp").alias("hit_time_utc_dt"),
    col("memberid").cast("string").alias("skymiles_customer_id"),
    col("adobe_mc_id").cast("string").alias("adobe_mc_id"),
    col("adobe_last_click").cast("string").alias("adobe_last_click_str"),
    col("pnr").cast("string").alias("pnr_str"),
    col("pnr_split_date").cast("string").alias("pnr_split_date_str"),
    col("visit_ticket_delim_raw").cast("string").alias("visit_ticket_delim_raw_str"),
    col("ticket_delim_processed").cast("string").alias("ticket_delim_processed_str"),
    col("trip_type").cast("string").alias("trip_type_str"),
    col("total_revenue").cast(DecimalType(18,4)).alias("total_revenue_amt"),
    col("skymiles_used").cast("long").alias("skymiles_used_qty"),
    col("taxes_fees").cast(DecimalType(18,4)).alias("taxes_fees_amt"),
    col("cash_revenue").cast(DecimalType(18,4)).alias("cash_revenue_amt"),
    col("datafeed_source").cast("string").alias("datafeed_source_str"),
    col("tkt_doc_nb").cast("string").alias("tkt_doc_num")
)

# --- Truncate visit_ticket_delim_raw_str to safe length (max 5000) and ticket_delim_processed_str to 10000 ---
def truncate_string_udf(max_length):
    return udf(lambda x: x[:max_length] if x is not None else x, StringType())

final_df = final_df.withColumn(
    "visit_ticket_delim_raw_str",
    truncate_string_udf(10000)(col("visit_ticket_delim_raw_str"))
).withColumn(
    "ticket_delim_processed_str",
    truncate_string_udf(10000)(col("ticket_delim_processed_str"))
)

# --- Write to S3 (optional for debugging or backup) ---
output_path = "s3://873109961464-lake-refined/intelligence-engine/ie_adb_ticket_extract"
final_df.write.mode("overwrite").csv(output_path)

# --- Function to generate Redshift schema/table SQL ---
def generate_create_schema_and_table_sql(df, schema_name, table_name):
    type_map = {
        "StringType": "VARCHAR(256)",
        "IntegerType": "INT",
        "LongType": "BIGINT",
        "DoubleType": "DOUBLE PRECISION",
        "FloatType": "FLOAT",
        "DecimalType": "DECIMAL(18,4)",
        "TimestampType": "TIMESTAMP",
        "BooleanType": "BOOLEAN",
        "DateType": "DATE"
    }
    columns = []
    for f in df.schema.fields:
        # Special handling for the two long string columns
        if f.name == "visit_ticket_delim_raw_str":
            columns.append(f"{f.name} VARCHAR(10000)")
        elif f.name == "ticket_delim_processed_str":
            columns.append(f"{f.name} VARCHAR(10000)")
        else:
            redshift_type = type_map.get(type(f.dataType).__name__, "VARCHAR(256)")
            columns.append(f"{f.name} {redshift_type}")
    columns_str = ", ".join(columns)
    sql = (
        f"CREATE SCHEMA IF NOT EXISTS {schema_name}; "
        f"DROP TABLE IF EXISTS {schema_name}.{table_name}; "
        f"CREATE TABLE {schema_name}.{table_name} ({columns_str});"
    )
    return sql

# --- Write to Redshift ---
SCHEMA_NAME = "ie_silver"
TABLE_NAME = "adb_ticket_extract"
preactions_sql = generate_create_schema_and_table_sql(final_df, SCHEMA_NAME, TABLE_NAME)
print("Preactions SQL:", preactions_sql)

dynamic_frame_renamed = DynamicFrame.fromDF(final_df, glueContext, "dynamic_frame_renamed")

try:
    glueContext.write_dynamic_frame.from_jdbc_conf(
        frame=dynamic_frame_renamed,
        catalog_connection="svcie-marketing-development-ie",
        connection_options={
            "dbtable": f"{SCHEMA_NAME}.{TABLE_NAME}",
            "database": "ie",
            "preactions": preactions_sql
        },
        redshift_tmp_dir="s3://aws-glue-assets-873109961464-us-west-2/temporary/",
        transformation_ctx="redshift_sink"
    )
except Exception as e:
    print("Exception during Redshift write:", e)
    traceback.print_exc()
    raise

job.commit()