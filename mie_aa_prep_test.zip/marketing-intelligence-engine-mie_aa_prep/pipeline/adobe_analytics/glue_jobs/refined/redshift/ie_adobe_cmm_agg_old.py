import sys
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame

# Get job parameters
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Initialize Glue context
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Initialize Glue job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Read table from Glue Data Catalog
adobe_cmm = glueContext.create_dynamic_frame.from_catalog(
    database="ie_dev",
    table_name="adobe_cmm"
)

# Set the S3 bucket for CSV output

output_s3_path = "s3://873109961464-lake-refined/intelligence-engine/ie_adb_cmm_agg_test/"
# Convert DynamicFrame to DataFrame and rename columns
df1 = adobe_cmm.toDF()
df1_renamed = (
    df1.withColumnRenamed("activity_date", "activity_dt")
    .withColumnRenamed("referring_domains", "referring_domains_str")
    .withColumnRenamed("tracking_code", "tracking_cd")
    .withColumnRenamed("internal_campaign_code", "internal_campaign_cd")
    .withColumnRenamed("unique_visitors", "unique_visitors_ct")
    .withColumnRenamed("visits", "visits_ct")
    .withColumnRenamed("total_time_seconds", "total_time_seconds_num")
    .withColumnRenamed("page_views", "page_views_ct")
    .withColumnRenamed("flight_searches", "flight_searches_ct")
    .withColumnRenamed("internal_campaign_clickthrough", "internal_campaign_clickthrough_ct")
    .withColumnRenamed("skymiles_enrollments", "skymiles_enrollments_ct")
)

# Write DataFrame as CSV to S3
df1_renamed.write.mode("overwrite").csv(output_s3_path)

# Prepare schema/table names for Redshift
SCHEMA_NAME = "ie_silver"
TABLE_NAME = "adobe_cmm"


# Function to generate Redshift-compatible CREATE TABLE SQL
def generate_create_schema_and_table_sql(df, schema_name, table_name):
    type_map = {
        "StringType": "VARCHAR(256)",
        "IntegerType": "INT",
        "LongType": "BIGINT",
        "DoubleType": "DOUBLE PRECISION",
        "FloatType": "FLOAT",
        "DecimalType": "DECIMAL(18,4)",
        "TimestampType": "TIMESTAMP",
        "BooleanType": "BOOLEAN",
        "DateType": "DATE"
    }
    columns = []
    for f in df.schema.fields:
        redshift_type = type_map.get(type(f.dataType).__name__, "VARCHAR(256)")
        columns.append(f"{f.name} {redshift_type}")
    columns_str = ", ".join(columns)
    sql = (
        f"CREATE SCHEMA IF NOT EXISTS {schema_name}; "
        f"DROP TABLE IF EXISTS {schema_name}.{table_name}; "
        f"CREATE TABLE {schema_name}.{table_name} ({columns_str});"
    )
    return sql


# Generate preactions SQL using the Spark DataFrame
preactions_sql = generate_create_schema_and_table_sql(df1_renamed, SCHEMA_NAME, TABLE_NAME)
print("Preactions SQL:", preactions_sql)

# Convert Spark DataFrame to DynamicFrame for Redshift write

dynamic_frame_renamed = DynamicFrame.fromDF(df1_renamed, glueContext, "dynamic_frame_renamed")

# Write to Redshift with schema and table creation

try:

    glueContext.write_dynamic_frame.from_options(

        frame=dynamic_frame_renamed,

        connection_type="redshift",

        connection_options={

            "dbtable": f"{SCHEMA_NAME}.{TABLE_NAME}",

            "database": "ie",

            "redshiftTmpDir": "s3://aws-glue-assets-873109961464-us-west-2/temporary/",

            "useConnectionProperties": True,  # Boolean, not string

            "connectionName": "svcie-marketing-development-ie",

            "preactions": preactions_sql

        },

        transformation_ctx="redshift_sink"

    )

except Exception as e:

    import traceback

    print("Exception during Redshift write:", e)

    traceback.print_exc()

    raise

# Commit the Glue job

job.commit()
