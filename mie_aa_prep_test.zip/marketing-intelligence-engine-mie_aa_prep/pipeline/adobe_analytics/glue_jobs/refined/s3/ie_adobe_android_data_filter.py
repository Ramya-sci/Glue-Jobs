import sys
import json
import re
import boto3
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import (
    col, when, regexp_replace, udf, lit, length, trim, substring, concat_ws, to_date, expr, to_timestamp
)
from pyspark.sql.types import StringType, FloatType, DecimalType
from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from pyspark.sql.functions import from_unixtime

# Get job parameters
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Initialize Spark and Glue context
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Initialize Glue job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# --- Step 1: Read main source table ---
database_name = "ie_dev"
table_name = "android"
dynamic_frame = glueContext.create_dynamic_frame.from_catalog(
    database=database_name,
    table_name=table_name
)
df = dynamic_frame.toDF().select("campaign", "click_action", "click_action_type", "click_context", "click_context_type",
                                 "click_sourceid", "click_tag", "duplicate_events", "duplicate_purchase", "exclude_hit",
                                 "first_hit_page_url", "first_hit_pagename", "first_hit_ref_domain",
                                 "first_hit_ref_type", "first_hit_referrer", "first_hit_time_gmt", "geo_city",
                                 "geo_country", "geo_dma", "geo_region", "geo_zip", "hit_source", "hit_time_gmt",
                                 "hitid_high", "hitid_low", "homepage", "hourly_visitor", "ip", "ip2",
                                 "last_hit_time_gmt", "last_purchase_num", "last_purchase_time_gmt", "mcvisid",
                                 "new_visit", "post_campaign", "post_channel", "post_evar1", "post_evar2", "post_evar3",
                                 "post_evar4", "post_evar5", "post_evar6", "post_evar7", "post_evar8", "post_evar9",
                                 "post_evar10", "post_evar11", "post_evar12", "post_evar13", "post_evar14",
                                 "post_evar15", "post_evar16", "post_evar17", "post_evar18", "post_evar19",
                                 "post_evar20", "post_evar21", "post_evar22", "post_evar23", "post_evar24",
                                 "post_evar25", "post_evar26", "post_evar27", "post_evar28", "post_evar29",
                                 "post_evar30", "post_evar31", "post_evar32", "post_evar33", "post_evar34",
                                 "post_evar35", "post_evar36", "post_evar37", "post_evar38", "post_evar39",
                                 "post_evar40", "post_evar41", "post_evar42", "post_evar43", "post_evar44",
                                 "post_evar45", "post_evar46", "post_evar47", "post_evar48", "post_evar49",
                                 "post_evar50", "post_evar51", "post_evar52", "post_evar53", "post_evar54",
                                 "post_evar55", "post_evar56", "post_evar57", "post_evar58", "post_evar59",
                                 "post_evar60", "post_evar61", "post_evar62", "post_evar63", "post_evar64",
                                 "post_evar65", "post_evar66", "post_evar67", "post_evar68", "post_evar69",
                                 "post_evar70", "post_evar71", "post_evar72", "post_evar73", "post_evar74",
                                 "post_evar75", "post_evar76", "post_evar77", "post_evar78", "post_evar79",
                                 "post_evar80", "post_evar81", "post_evar82", "post_evar83", "post_evar84",
                                 "post_evar85", "post_evar86", "post_evar87", "post_evar88", "post_evar89",
                                 "post_evar90", "post_evar91", "post_evar92", "post_evar93", "post_evar94",
                                 "post_evar95", "post_evar96", "post_evar97", "post_evar98", "post_evar99",
                                 "post_evar100", "post_evar101", "post_evar102", "post_evar103", "post_evar104",
                                 "post_evar105", "post_evar106", "post_evar107", "post_evar108", "post_evar109",
                                 "post_evar110", "post_evar111", "post_evar112", "post_evar113", "post_evar114",
                                 "post_evar115", "post_evar116", "post_evar117", "post_evar118", "post_evar119",
                                 "post_evar120", "post_evar121", "post_evar122", "post_evar123", "post_evar124",
                                 "post_evar125", "post_evar126", "post_evar127", "post_evar128", "post_evar129",
                                 "post_evar130", "post_evar131", "post_evar132", "post_evar133", "post_evar134",
                                 "post_evar135", "post_evar136", "post_evar137", "post_evar138", "post_evar139",
                                 "post_evar140", "post_evar141", "post_evar142", "post_evar143", "post_evar144",
                                 "post_evar145", "post_evar146", "post_evar147", "post_evar148", "post_evar149",
                                 "post_evar150", "post_evar151", "post_evar152", "post_evar153", "post_evar154",
                                 "post_evar155", "post_evar156", "post_evar157", "post_evar158", "post_evar159",
                                 "post_evar160", "post_evar161", "post_evar162", "post_evar163", "post_evar164",
                                 "post_evar165", "post_evar166", "post_evar167", "post_evar168", "post_evar169",
                                 "post_evar170", "post_evar171", "post_evar172", "post_evar173", "post_evar174",
                                 "post_evar175", "post_evar176", "post_evar177", "post_evar178", "post_evar179",
                                 "post_evar180", "post_evar181", "post_evar182", "post_evar183", "post_evar184",
                                 "post_evar185", "post_evar186", "post_evar187", "post_evar188", "post_evar189",
                                 "post_evar190", "post_evar191", "post_evar192", "post_evar193", "post_evar194",
                                 "post_evar195", "post_evar196", "post_evar197", "post_evar198", "post_evar199",
                                 "post_evar200", "post_event_list", "post_mc_audiences", "post_mobileaction",
                                 "post_mobileappid", "post_mobilecampaigncontent", "post_mobilecampaignmedium",
                                 "post_mobilecampaignname", "post_mobilecampaignsource", "post_mobilecampaignterm",
                                 "post_mobiledayofweek", "post_mobiledayssincefirstuse", "post_mobiledayssincelastuse",
                                 "post_mobiledevice", "post_mobilehourofday", "post_mobileinstalldate",
                                 "post_mobilelaunchnumber", "post_mobileltv", "post_mobilemessageid",
                                 "post_mobilemessageonline", "post_mobileosversion", "post_mobilepushoptin",
                                 "post_mobilepushpayloadid", "post_mobileresolution", "post_mvvar1", "post_mvvar2",
                                 "post_mvvar3", "post_page_event", "post_page_event_var1", "post_page_event_var2",
                                 "post_page_event_var3", "post_page_type", "post_page_url", "post_pagename",
                                 "post_pagename_no_url", "post_product_list", "post_prop1", "post_prop2", "post_prop3",
                                 "post_prop4", "post_prop5", "post_prop6", "post_prop7", "post_prop8", "post_prop9",
                                 "post_prop10", "post_prop11", "post_prop12", "post_prop13", "post_prop14",
                                 "post_prop15", "post_prop16", "post_prop17", "post_prop18", "post_prop19",
                                 "post_prop20", "post_prop21", "post_prop22", "post_prop23", "post_prop24",
                                 "post_prop25", "post_prop26", "post_prop27", "post_prop28", "post_prop29",
                                 "post_prop30", "post_prop31", "post_prop32", "post_prop33", "post_prop34",
                                 "post_prop35", "post_prop36", "post_prop37", "post_prop38", "post_prop39",
                                 "post_prop40", "post_prop41", "post_prop42", "post_prop43", "post_prop44",
                                 "post_prop45", "post_prop46", "post_prop47", "post_prop48", "post_prop49",
                                 "post_prop50", "post_prop51", "post_prop52", "post_prop53", "post_prop54",
                                 "post_prop55", "post_prop56", "post_prop57", "post_prop58", "post_prop59",
                                 "post_prop60", "post_prop61", "post_prop62", "post_prop63", "post_prop64",
                                 "post_prop65", "post_prop66", "post_prop67", "post_prop68", "post_prop69",
                                 "post_prop70", "post_prop71", "post_prop72", "post_prop73", "post_prop74",
                                 "post_prop75", "post_purchaseid", "post_t_time_info", "post_tnt", "post_tnt_action",
                                 "post_transactionid", "post_visid_high", "post_visid_low", "post_zip", "prev_page",
                                 "visit_keywords", "visit_num", "visit_page_num", "visit_ref_domain", "visit_ref_type",
                                 "visit_referrer", "visit_search_engine", "visit_start_page_url",
                                 "visit_start_pagename", "visit_start_time_gmt", "weekly_visitor", "yearly_visitor",
                                 "year", "month", "day"
                                 )

# List of columns to transform
columns_to_transform = ["campaign", "click_action", "click_action_type", "click_context", "click_context_type",
                        "click_sourceid", "click_tag", "duplicate_events", "duplicate_purchase", "exclude_hit",
                        "first_hit_page_url", "first_hit_pagename", "first_hit_ref_domain", "first_hit_ref_type",
                        "first_hit_referrer", "first_hit_time_gmt", "geo_city", "geo_country", "geo_dma", "geo_region",
                        "geo_zip", "hit_source", "hit_time_gmt", "hitid_high", "hitid_low", "homepage",
                        "hourly_visitor", "ip", "ip2", "last_hit_time_gmt", "last_purchase_num",
                        "last_purchase_time_gmt", "mcvisid", "new_visit", "post_campaign", "post_channel", "post_evar1",
                        "post_evar2", "post_evar3", "post_evar4", "post_evar5", "post_evar6", "post_evar7",
                        "post_evar8", "post_evar9", "post_evar10", "post_evar11", "post_evar12", "post_evar13",
                        "post_evar14", "post_evar15", "post_evar16", "post_evar17", "post_evar18", "post_evar19",
                        "post_evar20", "post_evar21", "post_evar22", "post_evar23", "post_evar24", "post_evar25",
                        "post_evar26", "post_evar27", "post_evar28", "post_evar29", "post_evar30", "post_evar31",
                        "post_evar32", "post_evar33", "post_evar34", "post_evar35", "post_evar36", "post_evar37",
                        "post_evar38", "post_evar39", "post_evar40", "post_evar41", "post_evar42", "post_evar43",
                        "post_evar44", "post_evar45", "post_evar46", "post_evar47", "post_evar48", "post_evar49",
                        "post_evar50", "post_evar51", "post_evar52", "post_evar53", "post_evar54", "post_evar55",
                        "post_evar56", "post_evar57", "post_evar58", "post_evar59", "post_evar60", "post_evar61",
                        "post_evar62", "post_evar63", "post_evar64", "post_evar65", "post_evar66", "post_evar67",
                        "post_evar68", "post_evar69", "post_evar70", "post_evar71", "post_evar72", "post_evar73",
                        "post_evar74", "post_evar75", "post_evar76", "post_evar77", "post_evar78", "post_evar79",
                        "post_evar80", "post_evar81", "post_evar82", "post_evar83", "post_evar84", "post_evar85",
                        "post_evar86", "post_evar87", "post_evar88", "post_evar89", "post_evar90", "post_evar91",
                        "post_evar92", "post_evar93", "post_evar94", "post_evar95", "post_evar96", "post_evar97",
                        "post_evar98", "post_evar99", "post_evar100", "post_evar101", "post_evar102", "post_evar103",
                        "post_evar104", "post_evar105", "post_evar106", "post_evar107", "post_evar108", "post_evar109",
                        "post_evar110", "post_evar111", "post_evar112", "post_evar113", "post_evar114", "post_evar115",
                        "post_evar116", "post_evar117", "post_evar118", "post_evar119", "post_evar120", "post_evar121",
                        "post_evar122", "post_evar123", "post_evar124", "post_evar125", "post_evar126", "post_evar127",
                        "post_evar128", "post_evar129", "post_evar130", "post_evar131", "post_evar132", "post_evar133",
                        "post_evar134", "post_evar135", "post_evar136", "post_evar137", "post_evar138", "post_evar139",
                        "post_evar140", "post_evar141", "post_evar142", "post_evar143", "post_evar144", "post_evar145",
                        "post_evar146", "post_evar147", "post_evar148", "post_evar149", "post_evar150", "post_evar151",
                        "post_evar152", "post_evar153", "post_evar154", "post_evar155", "post_evar156", "post_evar157",
                        "post_evar158", "post_evar159", "post_evar160", "post_evar161", "post_evar162", "post_evar163",
                        "post_evar164", "post_evar165", "post_evar166", "post_evar167", "post_evar168", "post_evar169",
                        "post_evar170", "post_evar171", "post_evar172", "post_evar173", "post_evar174", "post_evar175",
                        "post_evar176", "post_evar177", "post_evar178", "post_evar179", "post_evar180", "post_evar181",
                        "post_evar182", "post_evar183", "post_evar184", "post_evar185", "post_evar186", "post_evar187",
                        "post_evar188", "post_evar189", "post_evar190", "post_evar191", "post_evar192", "post_evar193",
                        "post_evar194", "post_evar195", "post_evar196", "post_evar197", "post_evar198", "post_evar199",
                        "post_evar200", "post_event_list", "post_mc_audiences", "post_mobileaction", "post_mobileappid",
                        "post_mobilecampaigncontent", "post_mobilecampaignmedium", "post_mobilecampaignname",
                        "post_mobilecampaignsource", "post_mobilecampaignterm", "post_mobiledayofweek",
                        "post_mobiledayssincefirstuse", "post_mobiledayssincelastuse", "post_mobiledevice",
                        "post_mobilehourofday", "post_mobileinstalldate", "post_mobilelaunchnumber", "post_mobileltv",
                        "post_mobilemessageid", "post_mobilemessageonline", "post_mobileosversion",
                        "post_mobilepushoptin", "post_mobilepushpayloadid", "post_mobileresolution", "post_mvvar1",
                        "post_mvvar2", "post_mvvar3", "post_page_event", "post_page_event_var1", "post_page_event_var2",
                        "post_page_event_var3", "post_page_type", "post_page_url", "post_pagename",
                        "post_pagename_no_url", "post_product_list", "post_prop1", "post_prop2", "post_prop3",
                        "post_prop4", "post_prop5", "post_prop6", "post_prop7", "post_prop8", "post_prop9",
                        "post_prop10", "post_prop11", "post_prop12", "post_prop13", "post_prop14", "post_prop15",
                        "post_prop16", "post_prop17", "post_prop18", "post_prop19", "post_prop20", "post_prop21",
                        "post_prop22", "post_prop23", "post_prop24", "post_prop25", "post_prop26", "post_prop27",
                        "post_prop28", "post_prop29", "post_prop30", "post_prop31", "post_prop32", "post_prop33",
                        "post_prop34", "post_prop35", "post_prop36", "post_prop37", "post_prop38", "post_prop39",
                        "post_prop40", "post_prop41", "post_prop42", "post_prop43", "post_prop44", "post_prop45",
                        "post_prop46", "post_prop47", "post_prop48", "post_prop49", "post_prop50", "post_prop51",
                        "post_prop52", "post_prop53", "post_prop54", "post_prop55", "post_prop56", "post_prop57",
                        "post_prop58", "post_prop59", "post_prop60", "post_prop61", "post_prop62", "post_prop63",
                        "post_prop64", "post_prop65", "post_prop66", "post_prop67", "post_prop68", "post_prop69",
                        "post_prop70", "post_prop71", "post_prop72", "post_prop73", "post_prop74", "post_prop75",
                        "post_purchaseid", "post_t_time_info", "post_tnt", "post_tnt_action", "post_transactionid",
                        "post_visid_high", "post_visid_low", "post_zip", "prev_page", "visit_keywords", "visit_num",
                        "visit_page_num", "visit_ref_domain", "visit_ref_type", "visit_referrer", "visit_search_engine",
                        "visit_start_page_url", "visit_start_pagename", "visit_start_time_gmt", "weekly_visitor",
                        "yearly_visitor"]

# Apply transformation using a loop
for col_name in columns_to_transform:
    df = df.withColumn(col_name, when(col(col_name).isNull(), "").otherwise(
        regexp_replace(col(col_name).cast("string"), r"\\,", ","))
                       )


# --- Step 3: Define all UDFs (event_value, derived_value, passenger count, revenue) ---

def get_event_value(event_string, product_string, event_number):
    if event_string is None:
        sanitized_event_string = []
    else:
        sanitized_event_string = event_string.replace("\\,", ",").split(",")
    if product_string is None:
        splitted_product_string = []
    else:
        splitted_product_string = product_string.split(";")
    result = ""
    for i in sanitized_event_string:
        if i:
            event_parts = i.split("=")
            if event_number is None:
                if event_parts[0]:
                    continue
            elif event_number != event_parts[0]:
                continue
            if len(event_parts) == 2:
                result = event_parts[1]
            else:
                result = "true"
    for item in splitted_product_string:
        splitted_event_from_product_split = item.split("|")
        for item1 in splitted_event_from_product_split:
            splitted_event_part = item1.split("=")
            if len(splitted_event_part) == 2:
                if event_number is None:
                    if splitted_event_part[0]:
                        continue
                elif splitted_event_part[0] != event_number:
                    continue
                result = splitted_event_part[1]
    return result


get_event_value_udf = udf(get_event_value, StringType())


def get_derived_value(return_type, product_string):
    if product_string is None:
        sanitized_event_string = []
    else:
        sanitized_event_string = product_string.split(";")
    split1 = sanitized_event_string[1] if len(sanitized_event_string) > 1 else ""
    items = split1.split("-") if split1 else []
    result = ""
    if len(items) == 4:
        if return_type == "trip_type":
            result = items[1]
        elif return_type == "origin" or return_type == "orgin":
            result = items[2]
        elif return_type == "destination":
            result = items[3]
        elif return_type == "shop_type":
            result = items[0]
    return result


get_derived_value_udf = udf(get_derived_value, StringType())


def is_number(value):
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


def get_derived_passenger_count(product_string):
    if product_string is None:
        sanitized_event_string = []
    else:
        sanitized_event_string = product_string.split(";")
    split2 = sanitized_event_string[2] if len(sanitized_event_string) > 2 else ""
    return split2 if is_number(split2) else ""


get_derived_passenger_count_udf = udf(get_derived_passenger_count, StringType())


def get_derived_revenue(product_string):
    if product_string is None:
        sanitized_event_string = []
    else:
        sanitized_event_string = product_string.split(";")
    split3 = sanitized_event_string[3] if len(sanitized_event_string) > 3 else ""
    return split3 if is_number(split3) else ""


get_derived_revenue_udf = udf(get_derived_revenue, StringType())


# --- Step 4: Apply event mapping columns from JSON mapping (S3) ---
def read_json_from_s3(s3_path):
    match = re.match(r"s3://([^/]+)/(.+)", s3_path)
    if not match:
        raise ValueError(f"Invalid S3 path: {s3_path}")
    bucket, key = match.group(1), match.group(2)
    s3 = boto3.client("s3")
    response = s3.get_object(Bucket=bucket, Key=key)
    mapping = json.loads(response["Body"].read())
    return mapping


MAPPING_S3_PATH = "s3://873109961464-file-transfer/Adobe-DW/Export/Input_files/ie_adobe_filter_event_mapping.json"
event_mapping = read_json_from_s3(MAPPING_S3_PATH)

for col_name, event_number in event_mapping.items():
    df = df.withColumn(
        col_name,
        regexp_replace(
            get_event_value_udf(
                col("post_event_list"),
                col("post_product_list"),
                lit(event_number)
            ).cast("string"),
            r"\\\\,",
            ","
        )
    )

# --- Step 5: Apply derived value columns and clean ---
for derived_col, derived_type in [
    ("shop_type", "shop_type"),
    ("trip_type", "trip_type"),
    ("origin", "origin"),
    ("destination", "destination")
]:
    df = df.withColumn(
        derived_col,
        regexp_replace(
            get_derived_value_udf(lit(derived_type), col("post_product_list")).cast("string"),
            r"\\\\,",
            ","
        )
    )

# --- Step 6: Apply passenger count and revenue columns ---
df = df.withColumn(
    "passenger_count",
    regexp_replace(get_derived_passenger_count_udf(col("post_product_list")).cast("string"), r"\\\\,", ",")
).withColumn(
    "total_revenue",
    regexp_replace(get_derived_revenue_udf(col("post_product_list")).cast("string"), r"\\\\,", ",")
)

# --- Step 7: Add additional columns from desktop_additional_logic.csv as INDIVIDUAL LINES ---

# year, month, date: assume they exist or are taken from source
df = df.withColumn("year", col("year").cast("string"))
df = df.withColumn("month", col("month").cast("string"))
df = df.withColumn("day", col("day").cast("string"))

# datafeed_date: to_date(year || '-' || month || '-' || date, 'yyyy-mm-dd')
df = df.withColumn(
    "datafeed_date",
    to_date(concat_ws("-", col("year"), col("month"), col("day")), "yyyy-MM-dd"))

# hit_time_utc
df = df.withColumn("hit_time_utc", when(length(col("hit_time_gmt")) == 10,
                                        expr("timestamp_seconds(cast(hit_time_gmt as long))")
                                        ).otherwise(col("datafeed_date")))

# memberid
df = df.withColumn("memberid",
                   when(length(col("post_evar1")) == 10, col("post_evar1")).otherwise(lit(None)))

# adobe_mc_id
df = df.withColumn("adobe_mc_id",
                   when(length(col("mcvisid")) == 38, col("mcvisid")).otherwise(lit(None)))

# adobe_last_click
df = df.withColumn("adobe_last_click",
                   when(trim(col("post_campaign")) == "null", lit(None)).otherwise(trim(col("post_campaign"))))

# pnr
df = df.withColumn("pnr", substring(col("post_evar63"), 1, 6))

# pnr_split_date
df = df.withColumn("pnr_split_date",
                   when(length(col("pnr")) == 19, substring(col("pnr"), 7, 13)
                        ).otherwise(lit(None)))

# trip_type_android
df = df.withColumn("trip_type_android",
                   when(col("post_evar23") == "", lit(None)).otherwise(col("post_evar23")))

# total_revenue_android
df = df.withColumn("total_revenue_android", when(col("total_revenue") == "", lit(None))
                   .otherwise(col("total_revenue").cast("decimal(38,2)")))

# skymiles_used
df = df.withColumn(
    "skymiles_used", when(col("event77") == "", lit(None))
    .otherwise(col("event77").cast("decimal(38,2)")))

# taxes_fees
# df = df.withColumn("taxes_fees",when(col("event18") == "",lit(None)).otherwise(
#   expr("cast(to_number(event18, '9999999999D99') as decimal(38,2))")))

df = df.withColumn(
    "taxes_fees",
    when(col("event18") == "", lit(None)).otherwise(
        col("event18").cast("decimal(38,2)")))

# datafeed_source
df = df.withColumn("datafeed_source", lit("android"))

"""
# --- Step 8: Ensure final column order and count (601 fields) ---
final_columns = [col for col in df.columns]

# If needed, pad with null columns to reach 601 fields
if len(final_columns) < 601:
    for i in range(601 - len(final_columns)):
        null_col = f"__null_pad_{i}"
        df = df.withColumn(null_col, lit(None).cast(StringType()))
        final_columns.append(null_col)
elif len(final_columns) > 601:
    final_columns = final_columns[:601]

df = df.select(*final_columns)

"""
# --- Step 9: Write Parquet and as catalog table ---
output_path = "s3://873109961464-lake-refined/intelligence-engine/ie_adobe_android_filter"
df.write.mode("overwrite").parquet(output_path)
df.write.mode("overwrite").option("path", output_path).saveAsTable("ie_dev.adobe_android_filter")