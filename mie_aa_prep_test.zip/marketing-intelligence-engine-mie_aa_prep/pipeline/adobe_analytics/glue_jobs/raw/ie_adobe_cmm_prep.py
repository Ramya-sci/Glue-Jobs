import datetime
import logging
import re
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, to_date, udf, date_format, lit, when
from pyspark.sql.types import LongType, StringType, DateType

from config_parser import ConfigParser
from constants import JobStatus
from storage.storage_read_service import StorageReadService
from storage.storage_write_service import StorageWriteService

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

config_parser = ConfigParser()
storage_read_service = StorageReadService()
storage_write_service = StorageWriteService()

# Initialize Spark session
logger.info("Initializing Spark session")
sc = config_parser.init_spark()
df: DataFrame = storage_read_service.read()


@udf(returnType=StringType())
def replace_empty_string(column_value):
    """
    Replaces empty or null strings with 'unspecified'.

    Args:
        column_value: The column value to check

    Returns:
        The original value or 'unspecified' if empty/null
    """
    if column_value is None or len(column_value) == 0:
        return "unspecified"
    else:
        return column_value

try:
    logger.info("Applying transformations to dataframe")

    # Debug: Check for the presence of "Date" column
    logger.info("Columns in dataframe:")
    logger.info(df.columns)

    df = (
        df.withColumn("activity_date", to_date(col("Date"), "MMMM d, yyyy"))
        .withColumn("referring_domains", replace_empty_string(col("Referring Domains")))
        .withColumn("tracking_code", replace_empty_string(col("Tracking Code")))
        .withColumn("internal_campaign_code", replace_empty_string(col("Internal Campaign Tracking Code (v1) (evar1)")))
        .withColumn("unique_visitors", col("Unique Visitors").cast(LongType()))
        .withColumn("visits", col("Visits").cast(LongType()))
        .withColumn("total_time_seconds", col("Total Seconds Spent").cast(LongType()))
        .withColumn("page_views", col("Page Views").cast(LongType()))
        .withColumn("flight_searches", col("Flight Searches (Step 1) (event1)").cast(LongType()))
        .withColumn("internal_campaign_clickthrough", col("Internal Campaign Clickthrough (event29)").cast(LongType()))
        .withColumn("skymiles_enrollments", col("SkyMiles Enrollments (event36)").cast(LongType()))
        .withColumn("file_date", to_date(col("file_date"), "yyyyMMdd"))  # Ensure file_date is in date format
    )

    # Create new dataframe with only the transformed columns
    logger.info("Creating transformed dataframe with selected columns")
    transformed_df = df.select([
        "activity_date",
        "referring_domains",
        "tracking_code",
        "internal_campaign_code",
        "unique_visitors",
        "visits",
        "total_time_seconds",
        "page_views",
        "flight_searches",
        "internal_campaign_clickthrough",
        "skymiles_enrollments",
        "file_date"  # Including file_date for tracking data source
    ])

    # derive partition columns - ensure file_date is a date type before extracting components
    transformed_df = transformed_df.withColumn("year", date_format(col("file_date"), "yyyy")) \
        .withColumn("month", date_format(col("file_date"), "MM")) \
        .withColumn("day", date_format(col("file_date"), "dd"))

    storage_write_service.write(transformed_df)
    config_parser.store_status(JobStatus.COMPLETED)
    logger.info("mie_adobe_cmm_prep transformation and storage completed successfully")
except Exception as e:
    logger.error(f"Error during dataframe transformation: {str(e)}")
    config_parser.store_status(JobStatus.FAILED)
    # Raise the exception to propagate it further
    raise e
