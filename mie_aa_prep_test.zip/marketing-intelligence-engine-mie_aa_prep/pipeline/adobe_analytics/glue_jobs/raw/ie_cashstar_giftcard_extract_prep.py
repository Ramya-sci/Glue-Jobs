from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql.functions import col, when, lower, lit, to_date, date_format
from pyspark.sql.types import IntegerType, StringType, DoubleType, DateType, TimestampType, BooleanType
import sys

# Initialize Glue Context
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Input and output S3 paths
input_s3_path = "s3://873109961464-file-transfer/Adobe-DW/Export/ie_cashstar/year=2025/month=07/day=02/ie_cashstar_gc000.gz"
output_s3_path = "s3://873109961464-lake-refined/intelligence-engine/ie_cashstar_giftcard_extract"

# Read CSV file with header
df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load(input_s3_path)

# Convert column types

df = df \
    .withColumn("year", col("year").cast(IntegerType())) \
    .withColumn("month", col("month").cast(IntegerType())) \
    .withColumn("day", col("day").cast(IntegerType())) \
    .withColumn("purchase_datetime", col("purchase_datetime").cast(DateType())) \
    .withColumn("memberid", col("memberid").cast(StringType())) \
    .withColumn("ecid", col("ecid").cast(StringType())) \
    .withColumn("confirmationnumber", col("confirmationnumber").cast(StringType())) \
    .withColumn("plastic_giftcard_quantity", col("plastic_giftcard_quantity").cast(IntegerType())) \
    .withColumn("plastic_giftcard_revenue", col("plastic_giftcard_revenue").cast(IntegerType())) \
    .withColumn("digital_giftcard_quantity", col("digital_giftcard_quantity").cast(IntegerType())) \
    .withColumn("digital_giftcard_revenue", col("digital_giftcard_revenue").cast(IntegerType())) \
    .withColumn("taxes_fees", col("taxes_fees").cast(IntegerType())) \
    .withColumn("total_purchase_price", col("total_purchase_price").cast(IntegerType())) \
    .withColumn("promotional_product_purchased", col("promotional_product_purchased").cast(BooleanType())) \
    .withColumn("adobe_last_click", col("adobe_last_click").cast(StringType())) \
    .withColumn("lt_tc", col("lt_tc").cast(StringType())) \
    .withColumn("source", col("source").cast(StringType())) \
    .withColumn("internal_campaign_code", col("internal_campaign_code").cast(StringType()))

# Write the transformed data to Parquet format in the output S3 bucket
df.write.partitionBy("year", "month", "day").format("parquet").mode("overwrite").option("path",
                                                                                        output_s3_path).saveAsTable(
    "ie_dev.cashstar_giftcard_extract")

# Commit the Glue job
job.commit()