import sys
import os
from datetime import datetime
import boto3
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.context import GlueContext
from awsglue.job import Job
from mie_config import get_dates, update_job_run_history

CONFIG_TABLE_NAME = "mie_job_config"
HISTORY_TABLE_NAME = "mie_job_run_history"
BUCKET_NAME = "873109961464-file-transfer"
OUTPUT_PATH = "s3://873109961464-lake-refined/intelligence-engine/ie_adobe_cmm"
TABLE_NAME = "ie_dev.adobe_cmm"

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
job_name = args['JOB_NAME']
job_id = job_name
job_run_id = os.environ.get('JOB_RUN_ID', job_name + "-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"))

dynamo_client = boto3.client('dynamodb')
s3_client = boto3.client('s3')
current_utc = datetime.utcnow()

# Get config and schedule type
config_response = dynamo_client.get_item(TableName=CONFIG_TABLE_NAME, Key={'job_id': {'S': job_id}})
config = {k: list(v.values())[0] for k, v in config_response['Item'].items()}
schedule_type = config.get('schedule_type', 'daily')

# Handle batch argument parsing
if schedule_type == "batch":
    date_args = getResolvedOptions(sys.argv, ['start_date', 'end_date'])
    job_args = {'start_date': date_args['start_date'], 'end_date': date_args['end_date']}
else:
    job_args = {}

dates = get_dates(job_id, dynamo_client, CONFIG_TABLE_NAME, job_args, current_utc)
date_list = dates['date_list']

# Spark/Glue context
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)
job = Job(glueContext)
job.init(job_name, args)

job_status = "success"
failed_files = []

try:
    for process_date in date_list:
        filedate = process_date.strftime("%Y%m%d")
        input_key = f'Adobe-DW/Export/ie_cmm/dmcampaignmetricsv2_{filedate}.zip'
        output_key = f'Adobe-DW/Export/Extracted/ie_cmm/dmcampaignmetricsv2_{filedate}.csv'
        uncompressed_file_path = f"s3://{BUCKET_NAME}/{output_key}"

        print(f"Processing file for date {filedate}: {input_key}")

        # Download and unzip
        try:
            response = s3_client.get_object(Bucket=BUCKET_NAME, Key=input_key)
            import zipfile
            from io import BytesIO
            with zipfile.ZipFile(BytesIO(response['Body'].read()), 'r') as zip_ref:
                file_names = zip_ref.namelist()
                if not file_names:
                    print(f"No files in ZIP: {input_key}")
                    failed_files.append(input_key)
                    job_status = "failed"
                    continue
                uncompressed_data = zip_ref.read(file_names[0])
            s3_client.put_object(Bucket=BUCKET_NAME, Key=output_key, Body=uncompressed_data)
            print(f"Unzipped file {output_key} written to S3 successfully.")
        except Exception as e:
            print(f"Failed to unzip/upload for {input_key}: {e}")
            failed_files.append(input_key)
            job_status = "failed"
            continue

        # Read CSV, transform, and write
        try:
            from pyspark.sql.types import StringType, IntegerType
            from pyspark.sql.functions import col, when, lower, to_date, lit, date_format

            df = spark.read.csv(uncompressed_file_path, header=True, inferSchema=True)
            print(f"Loaded data for {filedate}, row count: {df.count()}")

            year = filedate[:4]
            month = filedate[4:6]
            day = filedate[6:8]

            df = (
                df.withColumn("Date", to_date(col("Date"), "MMMM dd, yyyy"))
                  .withColumn("Referring Domains", col("Referring Domains").cast(StringType()))
                  .withColumn("Tracking Code", col("Tracking Code").cast(StringType()))
                  .withColumn("Internal Campaign Tracking Code (v1) (evar1)", col("Internal Campaign Tracking Code (v1) (evar1)").cast(StringType()))
                  .withColumn("Unique Visitors", col("Unique Visitors").cast(IntegerType()))
                  .withColumn("Visits", col("Visits").cast(IntegerType()))
                  .withColumn("Total Seconds Spent", col("Total Seconds Spent").cast(IntegerType()))
                  .withColumn("Page Views", col("Page Views").cast(IntegerType()))
                  .withColumn("Flight Searches (Step 1) (event1)", col("Flight Searches (Step 1) (event1)").cast(IntegerType()))
                  .withColumn("Internal Campaign Clickthrough (event29)", col("Internal Campaign Clickthrough (event29)").cast(IntegerType()))
                  .withColumn("SkyMiles Enrollments (event36)", col("SkyMiles Enrollments (event36)").cast(IntegerType()))
            )
            df = (
                df.withColumn("Date", date_format(col("Date"), "yyyy-MM-dd"))
                  .withColumn("Referring Domains", when(col("Referring Domains") == "", "unspecified").otherwise(lower(col("Referring Domains"))))
                  .withColumn("Tracking code", when(col("Tracking Code") == "", "unspecified").otherwise(lower(col("Tracking Code"))))
                  .withColumn("Internal Campaign Tracking Code (v1) (evar1)", when(col("Internal Campaign Tracking Code (v1) (evar1)") == "", "unspecified").otherwise(lower(col("Internal Campaign Tracking Code (v1) (evar1)"))))
            )
            df_transformed = (
                df.withColumnRenamed("Date", "activity_date")
                  .withColumnRenamed("Referring Domains", "referring_Domains")
                  .withColumnRenamed("Tracking Code", "tracking_code")
                  .withColumnRenamed("Internal Campaign Tracking Code (v1) (evar1)", "internal_campaign_code")
                  .withColumnRenamed("Unique Visitors", "unique_visitors")
                  .withColumnRenamed("Visits", "visits")
                  .withColumnRenamed("Total Seconds Spent", "total_time_seconds")
                  .withColumnRenamed("Page Views", "page_views")
                  .withColumnRenamed("Flight Searches (Step 1) (event1)", "flight_searches")
                  .withColumnRenamed("Internal Campaign Clickthrough (event29)", "internal_campaign_clickthrough")
                  .withColumnRenamed("SkyMiles Enrollments (event36)", "skymiles_enrollments")
            )
            df_transformed = (
                df_transformed.withColumn("year", lit(year))
                              .withColumn("month", lit(month))
                              .withColumn("day", lit(day))
            )
            df_transformed.write.partitionBy("year", "month", "day").format("parquet").mode("overwrite").option("path", OUTPUT_PATH).saveAsTable(TABLE_NAME)
            print(f"SUCCESS: File processed and catalog table created for {filedate}.")
        except Exception as e:
            print(f"Failed processing/parquet/catalog for {filedate}: {e}")
            failed_files.append(input_key)
            job_status = "failed"
            continue

except Exception as e:
    job_status = "failed"
    print(f"Job failed at outer level: {e}")

finally:
    last_process_date = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    update_job_run_history(
        job_id,
        dynamo_client,
        HISTORY_TABLE_NAME,
        job_run_id,
        job_status,
        dates['start_date'],
        dates['end_date'],
        last_process_date
    )
    if failed_files:
        print(f"Files that failed to process: {failed_files}")
    print(f"Job run history updated with status: {job_status}")
    job.commit()