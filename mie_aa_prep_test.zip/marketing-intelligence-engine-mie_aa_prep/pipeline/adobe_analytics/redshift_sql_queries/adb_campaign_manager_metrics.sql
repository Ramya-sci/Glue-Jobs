CREATE TABLE marketing_intelligence_engine.adb_campaign_manager_metrics (
    activity_dt date ENCODE az64,
    referring_domains_str character varying(500) ENCODE lzo,
    tracking_cd character varying(500) ENCODE lzo,
    internal_campaign_cd character varying(500) ENCODE lzo,
    unique_visitors_ct bigint ENCODE az64,
    visits_ct bigint ENCODE az64,
    total_time_seconds_num bigint ENCODE az64,
    page_views_ct bigint ENCODE az64,
    flight_searches_ct bigint ENCODE az64,
    internal_campaign_clickthrough_ct bigint ENCODE az64,
    skymiles_enrollments_ct bigint ENCODE az64,
    file_dt date ENCODE az64,
    insert_dt timestamp without time zone default CURRENT_TIMESTAMP ENCODE az64,
    update_dt timestamp without time zone default CURRENT_TIMESTAMP ENCODE az64,
    _surrogate_key character varying(500) ENCODE lzo
)
DISTSTYLE EVEN
COMPOUND SORTKEY (activity_dt, tracking_cd);
