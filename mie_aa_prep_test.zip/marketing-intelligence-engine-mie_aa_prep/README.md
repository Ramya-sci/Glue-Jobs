# Marketing Intelligence Engine (MIE)
A comprehensive data pipeline platform for processing and analyzing marketing data from various sources, with primary focus on Adobe Analytics Campaign Manager metrics. Built on AWS using PySpark, AWS Glue, and Apache Airflow.

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Project Structure](#project-structure)
- [Data Flow](#data-flow)
- [Development](#development)
- [Monitoring](#monitoring)
- [Troubleshooting](#troubleshooting)

## Overview

The Marketing Intelligence Engine is a scalable ETL (Extract, Transform, Load) platform designed to:

- **Extract** data from various marketing platforms (currently Adobe Analytics)
- **Transform** raw data into structured, analytics-ready formats
- **Load** processed data into data warehouses (S3 Data Lake, Amazon Redshift)
- **Orchestrate** data workflows using Apache Airflow
- **Monitor** job execution and data quality

### Key Features

- **Multi-source Data Ingestion**: Support for Adobe Analytics and extensible for other marketing platforms
- **Flexible Configuration**: JSON-based job configuration stored in DynamoDB
- **Scalable Processing**: Serverless processing using AWS Glue with PySpark
- **Data Lake Architecture**: Structured data storage in S3 with Glue Catalog integration
- **UPSERT Operations**: Intelligent data merging in Redshift using surrogate keys
- **Workflow Orchestration**: Airflow DAGs for complex pipeline dependencies
- **Error Handling**: Comprehensive logging and job status tracking

## Architecture

### Core Components

1. **Pipeline Framework** (`pipeline/`): Core ETL logic and utilities
2. **Glue Jobs** (`pipeline/adobe_analytics/glue_jobs/`): Serverless data processing jobs
3. **Airflow DAGs** (`dags/`): Workflow orchestration
4. **Deployment Tools** (`deployment/`): Infrastructure deployment utilities

### AWS Services Used

- **AWS Glue**: Serverless ETL processing
- **Amazon S3**: Data lake storage (raw, refined, and processed data)
- **AWS Glue Catalog**: Metadata management and schema registry  
- **Amazon Redshift**: Data warehouse for analytics
- **Amazon DynamoDB**: Job configuration and run history storage
- **Apache Airflow**: Workflow orchestration (via Amazon MWAA)

## Prerequisites

### AWS Account Setup

- AWS Account with appropriate IAM permissions
- AWS Glue service role: `arn:aws:iam::873109961464:role/delegate-admin-glue`
- S3 buckets:
  - `873109961464-file-transfer`: Source data storage
  - `873109961464-lake-refined`: Processed data storage
  - `aws-glue-assets-873109961464-us-west-2`: Glue scripts and temporary files

### Development Environment

- Python 3.8+
- PySpark 3.x
- Apache Airflow 2.x
- AWS CLI configured with appropriate credentials

### Software Dependencies

```bash
pip install boto3 pyspark awsglue-libs apache-airflow
```

## Installation

### 1. Clone Repository

```bash
git clone  https://git.delta.com/marketing/intelligence-engine/marketing-intelligence-engine.git
cd marketing-intelligence-engine
```

### 2. Configure AWS Credentials

```bash
aws configure
# Or set environment variables:
# AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION
```

### 3. Deploy Glue Jobs

```bash
python deployment/glue_job_deployer.py
```

### 4. Deploy Utilities

```bash
python deployment/utils_deployer.py
```

## Configuration

### Job Configuration

Jobs are configured via JSON files stored in DynamoDB table `mie_job_config`. Example configuration:

```json
{
  "job_id": "mie_aa_cmm_prep",
  "job_name": "adobe_analytics_campaign_manager_metrics_prep",
  "start_date_offset": 1,
  "end_date_offset": 1,
  "source": {
    "type": "s3",
    "bucket": "873109961464-file-transfer",
    "prefix": "Adobe-DW/Export/ie_cmm",
    "file_pattern": "dmcampaignmetricsv2_%Y%m%d.zip",
    "file_type": "csv",
    "compression": "zip"
  },
  "destination": {
    "type": "redshift",
    "database": "lake",
    "schema": "marketing_intelligence_engine", 
    "table": "adb_campaign_manager_metrics",
    "merge_columns": ["activity_dt", "referring_domains_str", "tracking_cd", "internal_campaign_cd"]
  }
}
```

### Environment Configuration

Environment settings are configured via:

- `pipeline/utils/constants.py`: Global constants and environment variables
- `deployment/config.json`: Deployment-specific configuration
- Environment variable `ENVIRONMENT`: Controls environment-specific behavior

## Project Structure

```
marketing-intelligence-engine/
├── dags/                           # Airflow DAG definitions
│   └── adobe_analytics/
│       └── adobe_cmm_dag.py       # Adobe CMM pipeline orchestration
├── deployment/                     # Deployment utilities
│   ├── config.json                # Deployment configuration
│   ├── glue_job_deployer.py       # Glue job deployment script
│   └── utils_deployer.py          # Utils deployment script
├── pipeline/                       # Core ETL framework
│   ├── adobe_analytics/           # Adobe Analytics specific jobs
│   │   ├── config.json            # Job configurations
│   │   ├── glue_jobs/             # Glue job implementations
│   │   │   ├── raw/               # Raw data processing jobs
│   │   │   └── refined/           # Data transformation and loading jobs
│   │   └── redshift_sql_queries/  # SQL queries for Redshift operations
│   └── utils/                     # Shared utilities and services
│       ├── constants.py           # Global constants and enums
│       ├── config_parser.py       # Job configuration parser
│       ├── dynamodb_handler.py    # DynamoDB operations
│       ├── file_handler.py        # File operations (ZIP extraction)
│       ├── entities/              # Data models
│       │   ├── job_config.py      # Job configuration entities
│       │   └── job_run.py         # Job run tracking entities
│       └── storage/               # Storage service abstractions
│           ├── s3_storage_service.py      # S3 operations
│           ├── redshift_storage_service.py # Redshift operations
│           ├── glue_catalog_storage_service.py # Glue Catalog operations
│           ├── storage_read_service.py     # Unified read interface
│           └── storage_write_service.py    # Unified write interface
└── README.md                      # This file
```

### Key Components

#### Storage Services

- **S3StorageService** (`pipeline/utils/storage/s3_storage_service.py:43`): Handles S3 file operations, reading CSV files, writing Parquet files with partitioning
- **RedshiftStorageService** (`pipeline/utils/storage/redshift_storage_service.py:17`): Manages Redshift operations including UPSERT logic using surrogate keys
- **GlueCatalogStorageService**: Manages AWS Glue Catalog metadata and table operations

#### Configuration Management

- **ConfigParser** (`pipeline/utils/config_parser.py:24`): Singleton class for job configuration, Spark initialization, and date range management
- **JobConfig** (`pipeline/utils/entities/job_config.py:4`): Represents job configuration with source, destination, and processing parameters

#### File Processing

- **FileHandler** (`pipeline/utils/file_handler.py:18`): Handles compressed file extraction from S3, supports ZIP files

## Data Flow

### Adobe Analytics Campaign Manager Metrics Pipeline

1. **Raw Data Extraction** (`ie_adobe_cmm_prep`)
   - Downloads ZIP files from S3 source bucket
   - Extracts CSV files from ZIP archives
   - Applies data transformations and validation
   - Stores processed data in S3 Data Lake as Parquet files

2. **Data Aggregation** (`ie_adobe_cmm_agg`)
   - Reads processed Parquet files from Data Lake
   - Performs business logic transformations
   - Loads data into Redshift using UPSERT operations
   - Updates dimension and fact tables

### Data Storage Layers

1. **Raw Layer**: Original compressed files in S3
2. **Refined Layer**: Processed and validated Parquet files in S3 Data Lake
3. **Analytics Layer**: Aggregated and denormalized data in Redshift

## Development

### Adding New Data Sources

1. **Create Job Configuration**: Add new job config to DynamoDB `mie_job_config` table
2. **Implement Glue Jobs**: Create processing jobs in appropriate `glue_jobs/` subdirectory
3. **Configure Airflow DAG**: Add workflow orchestration in `dags/` directory
4. **Update Storage Services**: Extend storage services if needed for new data formats

### Testing

```bash
# Run unit tests
python -m pytest tests/

# Test individual Glue job locally
python pipeline/adobe_analytics/glue_jobs/raw/ie_adobe_cmm_prep.py \
  --job_id mie_aa_cmm_prep \
  --start_date 2024-01-01 \
  --end_date 2024-01-01
```

### Code Style

- Follow PEP 8 Python style guidelines
- Use type hints for function parameters and returns
- Include comprehensive logging at INFO level
- Document functions with docstrings

## Monitoring

### Job Status Tracking

Job execution status is tracked in DynamoDB table `mie_job_run_history`:

- **RUNNING**: Job is currently executing
- **COMPLETED**: Job finished successfully  
- **FAILED**: Job encountered an error
- **CANCELLED**: Job was manually cancelled

### Logging

All jobs produce structured logs accessible via:

- **AWS CloudWatch**: Glue job logs and metrics
- **Airflow UI**: DAG execution logs and task status
- **AWS Glue Console**: Job run history and detailed logs

### Monitoring Queries

```python
# Check recent job status
from pipeline.utils.dynamodb_handler import DynamodbHandler
handler = DynamodbHandler()
recent_runs = handler.get_recent_job_runs('mie_aa_cmm_prep', limit=10)
```

## Troubleshooting

### Common Issues

#### 1. **Job Configuration Not Found**
```
Error: No job_id provided in arguments or constructor
```
**Solution**: Ensure job configuration exists in DynamoDB `mie_job_config` table

#### 2. **S3 Access Denied**
```
Error: Access Denied when reading from S3
```
**Solution**: Verify Glue service role has appropriate S3 permissions

#### 3. **Redshift Connection Issues**
```
Error: Unable to connect to Redshift
```
**Solution**: Check Redshift connection configuration in `pipeline/utils/constants.py:41`

#### 4. **Date Range Errors**
```
Error: Start date cannot be after end date
```
**Solution**: Verify date parameters are in YYYY-MM-DD format

### Debugging Tips

1. **Enable Debug Logging**: Set logging level to DEBUG in job scripts
2. **Check DynamoDB Tables**: Verify job configuration and run history
3. **Monitor CloudWatch**: Review Glue job logs for detailed error messages
4. **Validate Data**: Use Spark DataFrame `.show()` and `.printSchema()` for debugging

### Getting Help

- Check CloudWatch logs for detailed error messages
- Review DynamoDB job run history for execution patterns
- Use AWS Glue job bookmarks for incremental processing
- Monitor data quality and volume metrics in job logs