# Empty __init__.py file to make the deployment directory a proper Python package
import os
import json
import subprocess
import logging
from typing import Dict, List, Any, Optional
import boto3


class GlueJobDeployer:
    """
    Deploys AWS Glue jobs for Python files in the pipeline folder.

    Follows the steps:
    1. Iterates through python files in pipeline folder
    2. Generates a Glue Job for each file
    3. Creates a CloudFormation template for the Glue Jobs
    4. Adds tags from the config file to the Glue Jobs
    5. Deploys the CloudFormation template to AWS using AWS CLI
    """

    def __init__(self,
                 pipeline_dir: str,
                 config_path: str,
                 output_template_path: str,
                 stack_name: str):
        """
        Initialize the GlueJobDeployer.

        Args:
            pipeline_dir: Directory containing Python files to convert to Glue jobs
            config_path: Path to configuration file with deployment settings
            output_template_path: Path where CloudFormation template will be saved
            stack_name: Name of the CloudFormation stack to create/update
        """
        self.pipeline_dir = pipeline_dir
        self.config_path = config_path
        self.output_template_path = output_template_path
        self.stack_name = stack_name
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config()
        self.glue_jobs = []

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from the config file."""
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"Failed to load config file: {e}")
            raise

    def find_python_files(self) -> List[str]:
        """
        Find all Python files in the pipeline directory, excluding __init__.py and files in the utils folder.

        Returns:
            List of paths to Python files
        """
        python_files = []
        for root, dirs, files in os.walk(self.pipeline_dir):
            # Skip utils directory
            print(f"Checking directory: {root}")
            if "utils" in root:
                print(f"----ignored directory: {root}")
                continue

            for file in files:
                if file.endswith(".py") and file != "__init__.py" and 'old' not in file:
                    python_files.append(os.path.join(root, file))

        return python_files

    def generate_job_definition(self, python_file: str) -> Dict[str, Any]:
        """
        Generate AWS Glue job definition for a Python file using PySpark.

        Args:
            python_file: Path to the Python file

        Returns:
            Dictionary containing Glue job definition
        """
        filename = os.path.basename(python_file)
        job_name = os.path.splitext(filename)[0]

        # Get default job parameters from config
        default_params = self.config.get("default_job_parameters", {})

        # Create job definition for PySpark
        job_definition = {
            "Name": job_name,
            "Command": {
                "Name": "glueetl",
                "ScriptLocation": f"s3://{self.config['script_bucket']['bucket_name']}"
                                  f"/{self.config['script_bucket']['prefix']}/{job_name}.py",
                "PythonVersion": "3",
            },
            "Role": self.config["glue_role_arn"],
            "DefaultArguments": default_params,
            "MaxRetries": 0,
            "Timeout": 60,  # Default timeout in minutes
            "GlueVersion": "3.0",
            "NumberOfWorkers": 2,
            "WorkerType": "G.1X"
        }

        # Apply job-specific overrides if defined in config
        if "job_specific_parameters" in self.config and job_name in self.config["job_specific_parameters"]:
            specific_params = self.config["job_specific_parameters"][job_name]
            job_definition.update(specific_params)

        return job_definition

    def create_cloudformation_template(self, job_definitions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Create a CloudFormation template with the Glue job resources.

        Args:
            job_definitions: List of Glue job definitions

        Returns:
            CloudFormation template as a dictionary
        """
        template = {
            "AWSTemplateFormatVersion": "2010-09-09",
            "Description": "AWS Glue Jobs for Marketing Intelligence Engine",
            "Resources": {}
        }

        for job_def in job_definitions:
            job_name = job_def["Name"]
            logical_id = f"GlueJob_{job_name.replace('-', '')}"

            template["Resources"][logical_id] = {
                "Type": "AWS::Glue::Job",
                "Properties": job_def
            }

            # Add tags if present in config
            if "tags" in self.config:
                template["Resources"][logical_id]["Properties"]["Tags"] = self.apply_tags(job_name)

        return template

    def apply_tags(self, job_name: str) -> List[Dict[str, str]]:
        """
        Apply tags from config to a Glue job.

        Args:
            job_name: Name of the Glue job

        Returns:
            List of tag dictionaries
        """
        tags = []

        if "tags" in self.config:
            for key, value in self.config["tags"].items():
                tags.append({"Key": key, "Value": value})

            # Add job-specific name tag
            tags.append({"Key": "Name", "Value": job_name})

        return tags

    def save_template(self, template: Dict[str, Any]) -> None:
        """
        Save the CloudFormation template to a file.

        Args:
            template: CloudFormation template as a dictionary
        """
        try:
            with open(self.output_template_path, 'w') as f:
                json.dump(template, f, indent=2)
                self.logger.info(f"CloudFormation template saved to {self.output_template_path}")
        except Exception as e:
            self.logger.error(f"Failed to save CloudFormation template: {e}")
            raise

    def deploy_cloudformation(self) -> None:
        """
        Deploy the CloudFormation template using AWS CLI.
        """
        try:
            # Construct the AWS CLI command for deploying CloudFormation
            command = [
                "aws", "cloudformation", "deploy",
                "--template-file", self.output_template_path,
                "--stack-name", self.stack_name,
                "--capabilities", "CAPABILITY_IAM",
                "--no-fail-on-empty-changeset"
            ]

            # Execute the command
            self.logger.info(f"Deploying CloudFormation stack: {self.stack_name}")
            result = subprocess.run(command, capture_output=True, text=True)

            if result.returncode == 0:
                self.logger.info("CloudFormation deployment successful")
                self.logger.debug(result.stdout)
            else:
                self.logger.error(f"CloudFormation deployment failed: {result.stderr}")
                raise Exception(f"CloudFormation deployment failed: {result.stderr}")
        except Exception as e:
            self.logger.error(f"Error during CloudFormation deployment: {e}")
            raise

    def upload_scripts_to_s3(self, python_files: List[str]) -> None:
        """
        Upload Python script files to the S3 bucket specified in the config.

        Args:
            python_files: List of paths to Python files to upload
        """
        try:
            s3_client = boto3.client('s3')
            bucket_name = self.config['script_bucket']['bucket_name']
            prefix = self.config['script_bucket']['prefix']

            self.logger.info(f"Uploading {len(python_files)} Python files to S3 bucket: {bucket_name}/{prefix}")

            for file_path in python_files:
                file_name = os.path.basename(file_path)
                s3_key = f"{prefix}/{file_name}"

                # Upload the file to S3
                s3_client.upload_file(
                    Filename=file_path,
                    Bucket=bucket_name,
                    Key=s3_key
                )
                self.logger.info(f"Uploaded {file_name} to s3://{bucket_name}/{s3_key}")

            self.logger.info("All Python files successfully uploaded to S3")
        except Exception as e:
            self.logger.error(f"Failed to upload Python files to S3: {e}")
            raise

    def deploy(self) -> None:
        """
        Execute the full deployment process:
        1. Find Python files to deploy
        2. Generate job definitions
        3. Upload Python files to S3
        4. Create CloudFormation template
        5. Save template
        6. Deploy to AWS
        """
        try:
            # Find Python files
            python_files = self.find_python_files()
            self.logger.info(f"Found {len(python_files)} Python files to deploy as Glue jobs")

            # Generate job definitions
            job_definitions = [self.generate_job_definition(file) for file in python_files]

            # Upload Python files to S3
            self.upload_scripts_to_s3(python_files)

            # Create CloudFormation template
            cf_template = self.create_cloudformation_template(job_definitions)

            # Save template to file
            self.save_template(cf_template)

            # Deploy to AWS
            # self.deploy_cloudformation()

            self.logger.info("Glue job deployment completed successfully")
        except Exception as e:
            self.logger.error(f"Deployment failed: {e}")
            raise


# Example usage:
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    # Define paths and parameters
    pipeline_directory = "../pipeline"
    config_file_path = "./config.json"
    output_template_file = "../.build/mie_glue_jobs_cloudformation.json"
    cloudformation_stack_name = "MIEGlueJobsStack"

    # Create deployer instance
    deployer = GlueJobDeployer(
        pipeline_dir=pipeline_directory,
        config_path=config_file_path,
        output_template_path=output_template_file,
        stack_name=cloudformation_stack_name
    )

    # Execute deployment
    deployer.deploy()
