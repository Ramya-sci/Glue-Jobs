# Glue Job Deployer
## Steps:
1. Iterates through python files in pipeline folder, ignore __init__.py and utils folder
2. Generates a Glue Job for each file
3. Uploads the Python files to AWS S3 bucket (aws-glue-assets-873109961464-us-west-2)
4. Creates a CloudFormation template for the Glue Jobs
5. Add tags from the config file to the Glue Jobs
6. Deploys the CloudFormation template to AWS using AWS CLI

# Utils Deployer
## Steps:
1. Creates a .build directory if it doesn't exist
2. Zips all files in the pipeline/utils folder into utils.zip
3. Uploads the utils.zip file to AWS S3 bucket (aws-glue-assets-873109961464-us-west-2)
4. Stores the file in the path scripts/mie/ within the S3 bucket
