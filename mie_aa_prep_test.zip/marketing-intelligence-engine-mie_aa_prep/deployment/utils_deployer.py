import os
import zipfile
import boto3
import logging
from pathlib import Path


class UtilsDeployer:
    """Class for deploying utility files to AWS."""

    def __init__(self, base_dir=None):
        """Initialize the UtilsDeployer.

        Args:
            base_dir (str, optional): Base directory of the project.
                                     Defaults to the parent directory of 'deployment'.
        """
        if base_dir is None:
            # Default to parent directory of the current file's directory
            self.base_dir = Path(__file__).parent.parent
        else:
            self.base_dir = Path(base_dir)

        self.utils_dir = self.base_dir / "pipeline" / "utils"
        self.build_dir = self.base_dir / ".build"
        self.zip_path = self.build_dir / "utils.zip"

        # Set up logging
        logging.basicConfig(level=logging.INFO,
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('UtilsDeployer')

    def zip_utils_folder(self):
        """Zip all files in the pipeline/utils folder.

        Creates the .build directory if it doesn't exist.

        Returns:
            Path: Path to the created zip file
        """
        # Create .build directory if it doesn't exist
        if not self.build_dir.exists():
            self.logger.info(f"Creating build directory at {self.build_dir}")
            self.build_dir.mkdir(parents=True)

        # Check if utils directory exists
        if not self.utils_dir.exists():
            raise FileNotFoundError(f"Utils directory not found at {self.utils_dir}")

        # Create zip file
        self.logger.info(f"Creating zip file at {self.zip_path}")
        with zipfile.ZipFile(self.zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Walk through all files in utils directory
            for root, _, files in os.walk(self.utils_dir):
                for file in files:
                    file_path = Path(root) / file
                    # Create a relative path for the zip file
                    relative_path = file_path.relative_to(self.utils_dir)
                    self.logger.debug(f"Adding {file_path} to zip as {relative_path}")
                    zipf.write(file_path, arcname=relative_path)

        self.logger.info(f"Successfully created zip file at {self.zip_path}")
        return self.zip_path

    def upload_utils(self):
        """Upload utils.zip to S3.

        Uploads to arn:aws:s3:::aws-glue-assets-873109961464-us-west-2/scripts/mie/
        in the us-west-2 region.

        Returns:
            bool: True if upload was successful
        """
        # Check if zip file exists, create it if not
        if not self.zip_path.exists():
            self.logger.info("utils.zip not found. Creating it now.")
            self.zip_utils_folder()

        # Extract bucket name and path from ARN
        bucket_name = "aws-glue-assets-873109961464-us-west-2"
        s3_key = "scripts/mie/utils.zip"

        # Create S3 client
        self.logger.info(f"Connecting to S3 in region us-west-2")
        s3_client = boto3.client('s3', region_name='us-west-2')

        # Upload file
        try:
            self.logger.info(f"Uploading {self.zip_path} to s3://{bucket_name}/{s3_key}")
            s3_client.upload_file(
                str(self.zip_path),
                bucket_name,
                s3_key
            )
            self.logger.info("Upload successful")
            return True
        except Exception as e:
            self.logger.error(f"Error uploading to S3: {e}")
            raise


if __name__ == "__main__":
    deployer = UtilsDeployer()
    deployer.zip_utils_folder()
    deployer.upload_utils()

